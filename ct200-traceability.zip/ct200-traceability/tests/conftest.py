import os
from pathlib import Path

import pytest

DATA = Path(__file__).resolve().parents[1] / "data"
V1 = DATA / "ct200_manual.pdf"
V2 = DATA / "ct200_manual_v2.pdf"


@pytest.fixture()
def env(tmp_path, monkeypatch):
    """Fresh SQLite DB + JSON generation store + mock LLM for every test."""
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'test.db'}")
    monkeypatch.setenv("GENERATION_STORE", "json")
    monkeypatch.setenv("JSON_STORE_PATH", str(tmp_path / "generations.json"))
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("OCR_MODE", "auto")
    monkeypatch.setenv("OCR_CROSSCHECK", "false")
    from app import config, db

    config.reset_settings()
    db.init_engine()
    yield tmp_path
    config.reset_settings()


@pytest.fixture()
def session(env):
    from app.db import session_scope

    s = session_scope()
    yield s
    s.close()


@pytest.fixture()
def client(env):
    from fastapi.testclient import TestClient

    from app.main import create_app

    with TestClient(create_app()) as c:
        yield c


def upload(client, path, slug="ct200"):
    with open(path, "rb") as f:
        r = client.post(f"/documents/{slug}/versions", files={"file": (path.name, f, "application/pdf")})
    assert r.status_code in (200, 201), r.text
    return r.json()


def node_id(client, number, version=None):
    params = {"q": number, "field": "heading"}
    if version:
        params["version"] = version
    hits = client.get("/documents/ct200/search", params=params).json()
    hit = [h for h in hits if h["section_number"] == number]
    assert len(hit) == 1, hits
    return hit[0]["node_id"]
