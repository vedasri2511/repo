"""Parser tests. Each test targets a specific irregularity found in the CT-200
PDF (see docs/pdf_inspection_notes.md) or a structural case the parser must
flag rather than silently get wrong."""
from pathlib import Path

import pytest

from app.parser import parse_pdf
from app.parser.extract import Line, PageLayout, TableItem
from app.parser.ocr import ocr_available
from app.parser.structure import build_tree

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture(scope="module")
def v1():
    return parse_pdf(DATA / "ct200_manual.pdf")


@pytest.fixture(scope="module")
def v2():
    return parse_pdf(DATA / "ct200_manual_v2.pdf")


# ---------------------------------------------------------------- real PDF ---

def test_duplicate_heading_title_gives_two_distinct_nodes_with_correct_parents(v1):
    error_codes = [n for n in v1.nodes if n.title == "Error Codes"]
    assert [n.key for n in error_codes] == ["4.2", "7.1"]
    assert error_codes[0].key != error_codes[1].key
    assert error_codes[0].parent_key == "4"
    assert error_codes[1].parent_key == "7"
    # they hold different content: 4.2 is the table, 7.1 the troubleshooting text
    assert error_codes[0].blocks[0].kind == "table"
    assert "Section 4.2" in error_codes[1].body_text


def test_skipped_level_attaches_to_nearest_existing_ancestor_and_warns(v1):
    n = v1.get("2.1.1.1")
    assert n.parent_key == "2.1"
    assert n.level == 4 and n.depth == 3
    assert any("2.1.1 does not exist" in w for w in n.warnings)
    assert "2.1.1.1" in v1.get("2.1").children


def test_out_of_order_sections_keep_reading_order_and_are_flagged(v1):
    chapter3 = v1.get("3")
    assert chapter3.children == ["3.1", "3.2", "3.4", "3.3"]  # as printed, not re-sorted
    assert v1.get("3.3").parent_key == "3" and v1.get("3.4").parent_key == "3"
    assert any("out of sequence" in w for w in v1.get("3.3").warnings)
    assert "Auto Shutoff" not in v1.get("3.3").body_text


def test_body_size_heading_is_still_a_heading(v1):
    n = v1.get("3.2")
    assert n.title == "Cuff Inflation Sequence" and n.parent_key == "3"
    assert n.heading_size == 11.0
    assert any("level taken from numbering" in w for w in n.warnings)
    # its text did not leak into 3.1
    assert "inflates the cuff" not in v1.get("3.1").body_text


def test_numbered_list_items_are_not_headings(v1):
    titles = {n.title for n in v1.nodes}
    assert not any(t.startswith(("Normal", "Elevated", "Hypertensive")) for t in titles)
    n = v1.get("3.3")
    lists = [b for b in n.blocks if b.kind == "list"]
    assert len(lists) == 1 and lists[0].ordered
    assert len(lists[0].items) == 5
    # the wrapped continuation line stays with item 5
    assert lists[0].items[4].endswith("recommends seeking immediate medical attention")
    assert "≥ 140" in lists[0].items[3]


def test_inline_cross_references_are_recorded_not_parsed_as_headings(v1):
    assert v1.get("3.3").refs == ["2.1", "4.3"]
    assert v1.get("7.1").refs == ["4.2"]
    assert len([n for n in v1.nodes if n.number == "2.1"]) == 1


def test_tables_are_extracted_with_multiline_cells_merged(v1, v2):
    t1 = v1.get("4.2").blocks[0]
    assert t1.kind == "table"
    assert t1.rows[0] == ["Code", "Meaning", "Device Behavior"]
    assert t1.rows[2] == ["E2", "Motion artifact detected during measurement",
                          "Aborts measurement, displays E2, prompts retry"]
    assert len(t1.rows) == 6  # header + E1..E5; nested cell rects are not extra tables
    assert [r[0] for r in v2.get("4.2").blocks[0].rows][-1] == "E6"
    spec = v1.get("2.1").blocks
    assert len(spec) == 1 and spec[0].rows[2] == ["Pressure range", "0–299 mmHg"]


def test_displaced_hyphen_glyphs_do_not_split_words(v1):
    body = v1.get("5.1").body_text
    assert "CT‑200 stores" in body and "non‑volatile" in body
    assert "CT 200" not in body


def test_layout_changes_alone_do_not_change_content_hashes(v1, v2):
    a, b = v1.by_key(), v2.by_key()
    changed = {k for k in a if k in b and a[k].content_hash != b[k].content_hash}
    assert changed == {"2.1.1.1", "3.2", "4.2", "4.3"}
    assert set(b) - set(a) == {"5.3"}
    # 3.1, 4.3, 6.1 and 8.1 are split across pages differently in v1 and v2
    for key in ("3.1", "6.1", "8.1", "5.1"):
        assert a[key].content_hash == b[key].content_hash


def test_paragraph_continues_across_page_break(v1):
    n = v1.get("3.1")
    assert n.page_start == 2 and n.page_end == 3
    paragraphs = [b for b in n.blocks if b.kind == "paragraph"]
    assert len(paragraphs) == 1
    assert "power on the device. Use the profile button" in paragraphs[0].text


def test_chapter_heading_at_page_bottom_still_owns_next_page_sections(v1):
    assert v1.get("2").page_start == 1 and v1.get("2.1").page_start == 2
    assert v1.get("2.1").parent_key == "2"
    assert v1.get("2").blocks == []


def test_title_and_full_glyph_coverage(v1, v2):
    assert v1.title == "CardioTrack CT-200 Home Blood Pressure Monitor — Technical & User Manual"
    for r in (v1, v2):
        assert r.stats["glyphs_assigned"] == r.stats["glyphs_total"]
        assert not any("glyph" in w for w in r.warnings)


@pytest.mark.skipif(not ocr_available(), reason="Tesseract not installed")
def test_forced_ocr_reconstructs_same_hierarchy_and_flags_every_node(v1):
    ocr = parse_pdf(DATA / "ct200_manual.pdf", ocr_mode="force")
    assert [(n.key, n.parent_key) for n in ocr.nodes] == [(n.key, n.parent_key) for n in v1.nodes]
    assert all(any("came from OCR" in w for w in n.warnings) for n in ocr.nodes[1:])


# ------------------------------------------------- synthetic layouts --------

def L(page, top, text, x0=33.0, bold=False, size=11.0):
    return Line(page=page, top=top, bottom=top + 11, x0=x0, x1=x0 + 6 * len(text),
                text=text, bold=bold, size=size)


def layout(page, *items, height=595.0):
    pl = PageLayout(page=page, height=height, items=list(items))
    pl.total_chars = pl.assigned_chars = 0
    return pl


def test_duplicate_section_number_gets_distinct_key_and_warning():
    r = build_tree([layout(1,
        L(1, 50, "1. Alpha", bold=True, size=16.5),
        L(1, 80, "1.1 First", bold=True, size=12.9), L(1, 100, "one"),
        L(1, 130, "1.1 Again", bold=True, size=12.9), L(1, 150, "two"))])
    keys = [n.key for n in r.nodes]
    assert keys == ["root", "1", "1.1", "1.1#2"]
    dup = r.get("1.1#2")
    assert dup.parent_key == "1" and dup.body_text == "two"
    assert any("more than once" in w for w in dup.warnings)


def test_child_printed_before_parent_still_finds_parent():
    r = build_tree([layout(1,
        L(1, 50, "1. Alpha", bold=True),
        L(1, 80, "1.2.1 Detail", bold=True), L(1, 100, "detail text"),
        L(1, 130, "1.2 Section", bold=True), L(1, 150, "section text"))])
    n = r.get("1.2.1")
    assert n.parent_key == "1.2"
    assert any("before its parent" in w for w in n.warnings)


def test_orphan_section_and_bad_cross_reference_are_flagged():
    r = build_tree([layout(1,
        L(1, 50, "1. Alpha", bold=True), L(1, 70, "see 9.9 for details"),
        L(1, 100, "4.1 Orphan", bold=True), L(1, 120, "text"))])
    assert r.get("4.1").parent_key == "root"
    assert any("attached to the document root" in w for w in r.get("4.1").warnings)
    assert any("9.9, which does not exist" in w for w in r.get("1").warnings)


def test_bold_unnumbered_line_is_kept_as_text_with_warning():
    r = build_tree([layout(1,
        L(1, 50, "1. Alpha", bold=True), L(1, 80, "Warning", bold=True), L(1, 100, "body"))])
    n = r.get("1")
    assert "Warning" in n.body_text
    assert any("not recognised as a numbered heading" in w for w in n.warnings)


def test_table_split_across_pages_is_merged():
    t1 = TableItem(page=1, top=100, bottom=550, rows=[["Code", "Meaning"], ["E1", "a"]])
    t2 = TableItem(page=2, top=40, bottom=80, rows=[["Code", "Meaning"], ["E2", "b"]])
    r = build_tree([layout(1, L(1, 50, "1. Alpha", bold=True), t1), layout(2, t2)])
    blocks = r.get("1").blocks
    assert len(blocks) == 1 and blocks[0].rows == [["Code", "Meaning"], ["E1", "a"], ["E2", "b"]]
