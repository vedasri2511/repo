"""End-to-end through the HTTP API: generate on v1, re-ingest v2, retrieve."""
import json

from app.services import generation as g
from app.services.diff import classify
from app.services.llm import MockLLM
from tests.conftest import V1, V2, node_id, upload


def scripted(monkeypatch, *responses):
    llm = MockLLM(responses=list(responses))
    monkeypatch.setattr("app.services.generation.get_client", lambda override=None: override or llm)
    return llm


def cases_for(section, quote, values_in_expected):
    return json.dumps({"test_cases": [{
        "title": f"Check {section} behaviour {i}", "objective": "verify requirement",
        "test_type": "boundary", "priority": "high", "preconditions": [],
        "steps": ["Trigger the condition"], "expected_result": f"Device {values_in_expected} as specified",
        "source_sections": [section], "source_quote": quote} for i in range(3)]})


def test_generation_goes_stale_after_v2_and_is_visible_on_retrieval(client, monkeypatch):
    upload(client, V1)
    n42, n11 = node_id(client, "4.2"), node_id(client, "1.1")
    sel_alarm = client.post("/selections", json={"name": "E3", "node_ids": [n42]}).json()["selection_id"]
    sel_use = client.post("/selections", json={"name": "use", "node_ids": [n11]}).json()["selection_id"]

    scripted(monkeypatch,
             cases_for("4.2", "Auto-deflates within 2 seconds, displays E3", "auto-deflates within 2 seconds"),
             cases_for("1.1", "arm circumference of 22–42 cm", "accepts arm circumference 22–42 cm"))
    r = client.post(f"/selections/{sel_alarm}/generations")
    assert r.status_code == 201, r.text
    gen_alarm = r.json()
    assert gen_alarm["staleness"]["status"] == "current"
    assert client.post(f"/selections/{sel_use}/generations").status_code == 201

    # same selection again: reused, no LLM call (script is empty now)
    again = client.post(f"/selections/{sel_alarm}/generations")
    assert again.status_code == 200 and again.json()["reused"] is True
    assert again.json()["generation_id"] == gen_alarm["generation_id"]

    upload(client, V2)

    got = client.get("/generations", params={"selection_id": sel_alarm}).json()
    assert len(got) == 1
    st = got[0]["staleness"]
    assert st["status"] == "stale" and st["evaluated_against_version"] == 2
    src = st["sources"][0]
    assert src["severity"] == "substantive" and "2 seconds" in src["removed_values"]
    assert "1.5 seconds" in src["added_values"]
    assert all(c["mentions_values_no_longer_in_source"] == ["2 seconds"] for c in st["test_cases"])
    assert "assert values no longer in the manual" in st["summary"]
    # the stored test cases and their source text are untouched
    assert got[0]["test_cases"] == gen_alarm["test_cases"]
    assert got[0]["sources"][0]["version"] == 1

    unchanged = client.get("/generations", params={"selection_id": sel_use}).json()[0]["staleness"]
    assert unchanged["status"] == "current"

    by_node = client.get(f"/nodes/{n42}/generations").json()
    assert [x["generation_id"] for x in by_node] == [gen_alarm["generation_id"]]
    assert client.get("/generations", params={"node_id": n11}).json()[0]["selection_name"] == "use"


def test_cross_reference_change_is_reported_as_related(client, monkeypatch):
    upload(client, V1)
    n71 = node_id(client, "7.1")
    sel = client.post("/selections", json={"name": "troubleshooting", "node_ids": [n71]}).json()["selection_id"]
    scripted(monkeypatch, cases_for("7.1", "If a code from Section 4.2 appears and persists", "shows support prompt"))
    client.post(f"/selections/{sel}/generations")
    upload(client, V2)
    st = client.get("/generations", params={"selection_id": sel}).json()[0]["staleness"]
    assert st["status"] == "current"   # 7.1's own text did not change ...
    assert st["related_changes"] == [{"from_section": "7.1", "referenced_section": "4.2",
                                      "node_id": node_id(client, "4.2"), "change": "modified"}]


def test_failed_generation_returns_502_and_is_inspectable(client, monkeypatch):
    upload(client, V1)
    sel = client.post("/selections", json={"name": "x", "node_ids": [node_id(client, "3.2")]}).json()["selection_id"]
    scripted(monkeypatch, "no", "still no", "never")
    r = client.post(f"/selections/{sel}/generations")
    assert r.status_code == 502
    gid = r.json()["generation_id"]
    detail = client.get(f"/generations/{gid}", params={"include_attempts": True}).json()
    assert detail["status"] == "failed" and len(detail["attempts"]) == 3 and "staleness" not in detail
    assert client.get("/generations", params={"selection_id": sel}).json() == []
    assert len(client.get("/generations", params={"selection_id": sel, "include_failed": True}).json()) == 1


def test_editorial_change_is_possibly_stale_not_current():
    d = classify("Cleaning", "Wipe the device with a soft, dry cloth.", "Cleaning",
                 "Wipe the device using a soft, dry cloth.")
    assert d["severity"] == "editorial"
    d = classify("Cleaning", "Do not submerge the device.", "Cleaning", "Submerge the device.")
    assert d["severity"] == "substantive"  # dropped negation counts


def test_mock_provider_default_scenario_produces_grounded_cases(client):
    upload(client, V1)
    sel = client.post("/selections", json={"name": "ch3", "node_ids": [node_id(client, "3")]}).json()["selection_id"]
    r = client.post(f"/selections/{sel}/generations")
    assert r.status_code == 201, r.text
    body = r.json()
    assert 3 <= len(body["test_cases"]) <= 5
    assert {s["section_number"] for s in body["sources"]} == {"3", "3.1", "3.2", "3.4", "3.3"}
    assert body["prompt_version"] == g.PROMPT_VERSION
