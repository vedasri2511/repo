"""Provider clients against canned HTTP responses (no network)."""
import httpx
import pytest

from app.services.llm import GeminiClient, LLMError, OpenAICompatibleClient


def fake_post(status, payload, seen):
    def _post(url, **kw):
        seen.update(url=url, **kw)
        return httpx.Response(status, json=payload, request=httpx.Request("POST", url))
    return _post


def test_groq_request_shape_and_parsing(monkeypatch):
    seen = {}
    monkeypatch.setattr(httpx, "post", fake_post(200, {"choices": [{"message": {"content": '{"test_cases": []}'}}],
                                                       "usage": {"total_tokens": 10}}, seen))
    r = OpenAICompatibleClient("groq", "k", "llama-3.3-70b-versatile", 5).complete("sys", "user")
    assert r.text == '{"test_cases": []}' and r.usage == {"total_tokens": 10}
    assert seen["url"].startswith("https://api.groq.com/") and seen["headers"]["Authorization"] == "Bearer k"
    assert seen["json"]["response_format"] == {"type": "json_object"}
    assert [m["role"] for m in seen["json"]["messages"]] == ["system", "user"]


def test_gemini_request_shape_and_parsing(monkeypatch):
    seen = {}
    payload = {"candidates": [{"content": {"parts": [{"text": '{"test_cases"'}, {"text": ": []}"}]}}]}
    monkeypatch.setattr(httpx, "post", fake_post(200, payload, seen))
    r = GeminiClient("k", "gemini-2.5-flash", 5).complete("sys", "user")
    assert r.text == '{"test_cases": []}'
    assert seen["json"]["generationConfig"]["responseMimeType"] == "application/json"
    assert seen["params"] == {"key": "k"}


@pytest.mark.parametrize("status,retryable", [(429, True), (503, True), (401, False), (400, False)])
def test_http_errors_are_classified(monkeypatch, status, retryable):
    monkeypatch.setattr(httpx, "post", fake_post(status, {"error": "x"}, {}))
    with pytest.raises(LLMError) as e:
        OpenAICompatibleClient("openrouter", "k", "m", 5).complete("s", "u")
    assert e.value.retryable is retryable


def test_gemini_blocked_response_without_content_is_retryable(monkeypatch):
    monkeypatch.setattr(httpx, "post", fake_post(200, {"candidates": [{"finishReason": "SAFETY"}]}, {}))
    with pytest.raises(LLMError) as e:
        GeminiClient("k", "m", 5).complete("s", "u")
    assert e.value.retryable
