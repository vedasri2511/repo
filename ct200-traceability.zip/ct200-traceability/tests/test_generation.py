"""LLM output handling: malformed / partial / ungrounded responses, retries,
idempotency, and both generation stores."""
import json

import mongomock
import pytest

from app.services import generation as g
from app.services.ingest import ingest_file
from app.services.llm import MockLLM
from app.services.selection import ItemRequest, create_selection
from app.services.store import JsonStore, MongoStore
from tests.conftest import V1


def case(section="4.2", quote="Auto-deflates within 2 seconds, displays E3", title="Verify E3 deflation", **kw):
    c = {"title": title, "objective": "Check overpressure handling", "test_type": "safety",
         "priority": "high", "preconditions": ["cuff connected"],
         "steps": ["Raise cuff pressure above 299 mmHg", "Observe display"],
         "expected_result": "Device displays E3 and deflates within 2 seconds",
         "source_sections": [section], "source_quote": quote}
    c.update(kw)
    return c


def good(n=4):
    return json.dumps({"test_cases": [case(title=f"Verify E3 deflation variant {i}") for i in range(n)]})


@pytest.fixture()
def sel(session):
    ingest_file(session, "ct200", V1)
    from app.services import tree

    v = tree.resolve_version(session, tree.get_document(session, "ct200").id, None)
    n42 = next(e for e in v.entries if e.section_key == "4.2").logical_node_id
    s, _ = create_selection(session, "ct200", "error codes", [ItemRequest(n42)], None, True)
    return s


# ------------------------------------------------------------ pure parts ---

@pytest.mark.parametrize("raw", [
    good(),
    "Here are the tests:\n```json\n" + good() + "\n```\nLet me know!",
    "Sure. " + good() + " Hope this helps.",
    json.dumps([case(title=f"Case number {i}") for i in range(3)]),          # bare list
    json.dumps({"result": json.loads(good())}),                               # one level of wrapping
])
def test_extract_json_tolerates_common_wrappers(raw):
    assert len(g.extract_json(raw)["test_cases"]) >= 3


@pytest.mark.parametrize("raw,msg", [
    ("", "empty"),
    ("I cannot help with that.", "no JSON"),
    ('{"test_cases": [{"title": "x"', "invalid JSON"),
    ('{"cases": []}', "missing 'test_cases'"),
    ('{"test_cases": "none"}', "not a list"),
])
def test_extract_json_rejects_unusable_output(raw, msg):
    with pytest.raises(ValueError, match=msg):
        g.extract_json(raw)


SOURCES = [{"node_id": 7, "section_number": "4.2", "title": "Error Codes",
            "body_text": "E3 | Overpressure condition | Auto-deflates within 2 seconds, displays E3"}]


def test_validation_rejects_ungrounded_and_unknown_sections_but_keeps_good_ones():
    raw = [
        case(),
        case(title="Wrong section", section="9.9"),
        case(title="Invented quote", quote="Device deflates within 0.5 seconds of fault"),
        case(title="Missing steps", steps=[]),
        case(title="Bad enum", test_type="exploratory"),
        case(title="verify e3 deflation"),  # duplicate (case-insensitive)
        case(title="Lower-case enums ok", test_type="Error Handling", priority="HIGH"),
        # close enough for fuzzy grounding (97% overlap) but the code at the end changed
        case(title="Code swapped in quote", quote="Overpressure condition Auto-deflates within 2 seconds, displays E9"),
    ]
    valid, rejected = g.validate_cases(raw, SOURCES)
    assert [c["title"] for c in valid] == ["Verify E3 deflation", "Lower-case enums ok"]
    assert valid[0]["source_node_ids"] == [7] and valid[1]["test_type"] == "error_handling"
    reasons = {r["raw"]["title"]: " ".join(r["reasons"]) for r in rejected}
    assert "not in the provided text" in reasons["Wrong section"]
    assert "does not appear verbatim" in reasons["Invented quote"]
    assert "steps" in reasons["Missing steps"]
    assert "test_type" in reasons["Bad enum"]
    assert "duplicate" in reasons["verify e3 deflation"]
    assert "values not in the cited text: ['E9']" in reasons["Code swapped in quote"]
    assert valid[0]["values_not_in_source"] == ["299 mmHg"]  # from the steps, kept but surfaced


def test_grounding_tolerates_whitespace_case_and_dash_differences_only():
    src = "Under typical use, four AA alkaline batteries provide approximately 300 measurement cycles"
    assert g.grounded("four AA alkaline  batteries provide approximately 300", src)
    assert g.grounded("FOUR AA ALKALINE BATTERIES PROVIDE APPROXIMATELY 300", src)
    # a changed number in a long quote is caught only if the unmatched part exceeds 15%:
    assert not g.grounded("approximately 500 measurement cycles", src)
    assert not g.grounded("rechargeable lithium cells last for one year of use", src)


# ------------------------------------------------------- full generation ---

def test_malformed_first_response_is_retried_with_repair_prompt(session, sel):
    llm = MockLLM(responses=["Sure! ```json {broken", good()])
    store = JsonStore(str(session.bind.url.database) + ".gen.json")
    gen, reused = g.generate(session, sel.id, client=llm, store=store)
    assert not reused and gen["status"] == "accepted"
    assert llm.calls == 2 and len(gen["test_cases"]) == 4
    assert "parse_error" in gen["attempts"][0]
    assert "accepted on attempt 2" in gen["warnings"]
    assert gen["sources"][0]["section_number"] == "4.2" and "2 seconds" in gen["sources"][0]["text"]


def test_partial_output_keeps_valid_cases_and_records_rejections(session, sel):
    raw = json.dumps({"test_cases": [case(title=f"Valid {i}") for i in range(3)] + [case(title="Bad", section="1.1")]})
    store = JsonStore(str(session.bind.url.database) + ".gen.json")
    gen, _ = g.generate(session, sel.id, client=MockLLM(responses=[raw]), store=store)
    assert gen["status"] == "accepted_with_warnings" and len(gen["test_cases"]) == 3
    assert gen["attempts"][0]["rejected_cases"][0]["raw"]["title"] == "Bad"


def test_too_many_cases_are_truncated_to_five(session, sel):
    store = JsonStore(str(session.bind.url.database) + ".gen.json")
    gen, _ = g.generate(session, sel.id, client=MockLLM(responses=[good(7)]), store=store)
    assert len(gen["test_cases"]) == 5 and any("kept the first 5" in w for w in gen["warnings"])


def test_persistently_bad_output_fails_and_is_stored_for_audit(session, sel):
    store = JsonStore(str(session.bind.url.database) + ".gen.json")
    llm = MockLLM(responses=["nope", '{"test_cases": []}', json.dumps({"test_cases": [case()] * 2})])
    with pytest.raises(g.GenerationFailed) as exc:
        g.generate(session, sel.id, client=llm, store=store)
    failed = store.get(exc.value.gen_id)
    assert failed["status"] == "failed" and failed["test_cases"] == []
    assert len(failed["attempts"]) == 3 and "need at least 3" in failed["error"]
    # a failed run is not reused: the next request calls the LLM again
    gen, reused = g.generate(session, sel.id, client=MockLLM(responses=[good()]), store=store)
    assert not reused and gen["status"] == "accepted"


def test_same_selection_twice_reuses_unless_forced(session, sel):
    store = JsonStore(str(session.bind.url.database) + ".gen.json")
    first, _ = g.generate(session, sel.id, client=MockLLM(responses=[good()]), store=store)
    llm = MockLLM(responses=[good()])
    second, reused = g.generate(session, sel.id, client=llm, store=store)
    assert reused and second["_id"] == first["_id"] and llm.calls == 0
    third, reused = g.generate(session, sel.id, force=True, client=MockLLM(responses=[good()]), store=store)
    assert not reused and third["_id"] != first["_id"] and third["supersedes"] == first["_id"]


def test_mongo_store_round_trip(session, sel):
    store = MongoStore("mongodb://unused", "ct200_test", client=mongomock.MongoClient())
    gen, _ = g.generate(session, sel.id, client=MockLLM(), store=store)
    assert store.get(gen["_id"])["status"] == "accepted"
    node = gen["sources"][0]["node_id"]
    assert [d["_id"] for d in store.find(node_id=node)] == [gen["_id"]]
    assert store.find(selection_id=sel.id)[0]["request_key"] == gen["request_key"]


def test_prompt_contains_pinned_text_and_rules():
    user = g.build_user_prompt("sel", [{"section_number": "3.2", "title": "Cuff Inflation Sequence",
                                        "body_text": "inflates in 40 mmHg increments"}])
    assert "### SECTION 3.2 — Cuff Inflation Sequence" in user and "40 mmHg" in user
    assert "VERBATIM" in g.SYSTEM_PROMPT and "ONLY the requirement text" in g.SYSTEM_PROMPT


def test_mock_output_is_grounded_for_a_single_short_section():
    """Regression: the demo run showed the mock quoting the prompt's closing
    instruction as if it were part of the last section; the validator caught it."""
    src = [{"node_id": 1, "section_number": "1.1", "title": "Intended Use",
            "body_text": "The CT-200 is intended to non-invasively measure blood pressure and pulse rate "
                         "in adults with an arm circumference of 22–42 cm. It is not intended for use on "
                         "neonates, infants, or pregnant users."}]
    raw = MockLLM().complete(g.SYSTEM_PROMPT, g.build_user_prompt("x", src)).text
    valid, rejected = g.validate_cases(g.extract_json(raw)["test_cases"], src)
    assert len(valid) >= 3 and not rejected
