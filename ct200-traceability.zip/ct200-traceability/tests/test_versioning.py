"""Versioning: v1 -> v2 re-ingestion, logical-node matching, browse API."""
from sqlalchemy import func, select

from app.models import DocumentVersion, NodeRevision, TreeEntry
from app.parser.model import Block, ParsedNode, ParseResult
from app.services.ingest import ingest_file
from app.services.matching import PrevNode, match_versions
from tests.conftest import V1, V2, node_id, upload


# ------------------------------------------------------------ matcher unit ---

def _node(key, title, body, parent="root"):
    return ParsedNode(key=key, number=None if key == "root" else key.split("#")[0], title=title,
                      level=0 if key == "root" else key.count(".") + 1, parent_key=None if key == "root" else parent,
                      order_index=0, page_start=1, page_end=1,
                      blocks=[Block(kind="paragraph", page=1, text=body)] if body else [])


def _prev(lid, n, parent_lid=None):
    return PrevNode(lid, n.key, n.number, n.title, n.content_hash, parent_lid, n.body_text)


def _result(*nodes):
    return ParseResult(title="t", nodes=list(nodes))


def test_matcher_renumbered_unchanged_section_is_moved_not_new():
    old = [_node("root", "t", ""), _node("1", "Ops", ""), _node("1.3", "Auto Shutoff", "60 seconds")]
    prev = [_prev(10, old[0]), _prev(11, old[1], 10), _prev(12, old[2], 11)]
    new = _result(_node("root", "t", ""), _node("1", "Ops", ""), _node("1.4", "Auto Shutoff", "60 seconds", "1"))
    m, report = match_versions(prev, new)
    assert m["1.4"].logical_id == 12 and m["1.4"].status == "moved" and m["1.4"].rule == "R2_content_hash"
    assert report["counts"]["added"] == 0 and report["counts"]["removed"] == 0


def test_matcher_renumbered_and_edited_section_matched_by_title_under_same_parent():
    old = [_node("root", "t", ""), _node("4", "Alarms", ""), _node("4.2", "Error Codes", "E3 within 2 seconds", "4")]
    prev = [_prev(1, old[0]), _prev(2, old[1], 1), _prev(3, old[2], 2)]
    new = _result(_node("root", "t", ""), _node("4", "Alarms", ""),
                  _node("4.5", "Error Codes", "E3 within 1.5 seconds", "4"))
    m, _ = match_versions(prev, new)
    assert m["4.5"].logical_id == 3 and m["4.5"].rule == "R3_title_parent" and m["4.5"].status == "modified"


def test_matcher_does_not_confuse_duplicate_titles_under_different_parents():
    old = [_node("root", "t", ""), _node("4", "Alarms", ""), _node("4.2", "Error Codes", "table", "4"),
           _node("7", "Troubleshooting", ""), _node("7.1", "Error Codes", "see 4.2", "7")]
    prev = [_prev(1, old[0]), _prev(2, old[1], 1), _prev(3, old[2], 2), _prev(4, old[3], 1), _prev(5, old[4], 4)]
    # 7.1 renumbered to 7.3 and edited: must link to 5 (parent 7), never to 3
    new = _result(*old[:4], _node("7.3", "Error Codes", "see section 4.2 first", "7"))
    m, _ = match_versions(prev, new)
    assert m["4.2"].logical_id == 3
    assert m["7.3"].logical_id == 5


def test_matcher_small_title_edit_and_removed_section():
    old = [_node("root", "t", ""), _node("2", "Specs", ""), _node("2.2", "Cuff Spec", "22-32 cm", "2"),
           _node("2.3", "Legacy", "gone", "2")]
    prev = [_prev(1, old[0]), _prev(2, old[1], 1), _prev(3, old[2], 2), _prev(4, old[3], 2)]
    new = _result(old[0], old[1], _node("2.2", "Cuff Specs", "22-32 cm", "2"))
    m, report = match_versions(prev, new)
    assert m["2.2"].logical_id == 3 and m["2.2"].rule == "R4_number_fuzzy_title"
    assert [r["key"] for r in report["removed"]] == ["2.3"]


# ------------------------------------------------------------ real ingest ---

def test_v2_reingest_reuses_unchanged_nodes_and_flags_changed(session):
    v1 = ingest_file(session, "ct200", V1).version
    v2 = ingest_file(session, "ct200", V2).version
    assert (v1.version_number, v2.version_number) == (1, 2)
    e1 = {e.section_key: e for e in v1.entries}
    e2 = {e.section_key: e for e in v2.entries}
    # same logical node for every section present in both
    for key in e1:
        assert e2[key].logical_node_id == e1[key].logical_node_id, key
    # unchanged sections share the very same revision row (no duplication)
    for key in ("1.1", "3.1", "4.1", "5.1", "6.1", "7.1", "8.1"):
        assert e2[key].revision_id == e1[key].revision_id
        assert e2[key].change_status == "unchanged"
    # changed sections got a new revision chained to the old one
    for key in ("2.1.1.1", "3.2", "4.2", "4.3"):
        assert e2[key].change_status == "modified"
        assert e2[key].revision_id != e1[key].revision_id
        assert e2[key].revision.previous_revision_id == e1[key].revision_id
    assert e2["5.3"].change_status == "added"
    assert set(v2.matching_report["modified"]) == {"2.1.1.1", "3.2", "4.2", "4.3"}
    assert v2.matching_report["added"] == ["5.3"]
    revisions = session.scalar(select(func.count()).select_from(NodeRevision))
    assert revisions == len(e1) + 5  # 4 modified + 1 added, nothing else copied
    # v1 is untouched
    assert session.get(TreeEntry, e1["4.2"].id).revision.body_text.count("2 seconds") == 1


def test_reingesting_identical_file_does_not_create_a_version(session):
    ingest_file(session, "ct200", V1)
    again = ingest_file(session, "ct200", V1)
    assert again.created is False
    assert session.scalar(select(func.count()).select_from(DocumentVersion)) == 1


# ------------------------------------------------------------------- API ---

def test_browse_api_versions_sections_node_search_and_changes(client):
    r1 = upload(client, V1)
    assert r1["created"] and r1["version"]["version"] == 1
    r2 = upload(client, V2)
    assert r2["changes_vs_previous"]["counts"] == {"unchanged": 24, "modified": 4, "moved": 0,
                                                   "added": 1, "removed": 0}
    assert upload(client, V2)["created"] is False

    secs = client.get("/documents/ct200/sections").json()
    assert [s["section_number"] for s in secs] == [str(i) for i in range(1, 9)]
    secs_v1 = client.get("/documents/ct200/sections", params={"version": 1}).json()
    assert [s["node_id"] for s in secs_v1] == [s["node_id"] for s in secs]

    n42 = node_id(client, "4.2")
    node = client.get(f"/nodes/{n42}").json()
    assert node["version"] == 2 and node["title"] == "Error Codes"
    assert node["parent"]["section_number"] == "4"
    assert "1.5 seconds" in node["body_text"] and len(node["content_hash"]) == 64
    old = client.get(f"/nodes/{n42}", params={"version": 1}).json()
    assert "within 2 seconds" in old["body_text"] and old["content_hash"] != node["content_hash"]

    ch4 = client.get(f"/nodes/{node_id(client, '4')}").json()
    assert [c["section_number"] for c in ch4["children"]] == ["4.1", "4.2", "4.3"]

    hits = client.get("/documents/ct200/search", params={"q": "error codes", "field": "heading"}).json()
    assert sorted(h["section_number"] for h in hits) == ["4.2", "7.1"]
    assert client.get("/documents/ct200/search", params={"q": "Data Export", "version": 1}).json() == []

    changes = client.get(f"/nodes/{n42}/changes").json()
    assert changes["changed_in_latest"] is True
    t = changes["transitions"][0]
    assert t["severity"] == "substantive" and "2 seconds" in t["normative_removed"]

    same = client.get(f"/nodes/{node_id(client, '1.1')}/changes").json()
    assert same["changed_in_any_version"] is False

    n53 = node_id(client, "5.3")
    assert client.get(f"/nodes/{n53}", params={"version": 1}).status_code == 404
    assert client.get(f"/nodes/{n53}/changes").json()["transitions"][0]["severity"] == "added"

    report = client.get("/documents/ct200/versions/1").json()
    assert any("2.1.1 does not exist" in w for w in report["node_warnings"]["2.1.1.1"])


def test_selection_is_version_pinned_and_creation_is_idempotent(client):
    upload(client, V1)
    n42 = node_id(client, "4.2")
    body = {"name": "alarms", "node_ids": [n42]}
    s1 = client.post("/selections", json=body)
    assert s1.status_code == 201 and s1.json()["created"] is True
    sel = s1.json()
    assert sel["nodes"][0]["version"] == 1 and "2 seconds" in sel["nodes"][0]["body_text"]

    upload(client, V2)
    again = client.get(f"/selections/{sel['selection_id']}").json()
    assert again["nodes"][0]["body_text"] == sel["nodes"][0]["body_text"]  # still v1 text
    assert again["nodes"][0]["current_in_latest"] is False

    dup = client.post("/selections", json={**body, "version": 1})   # same name + same pins
    assert dup.status_code == 200 and dup.json()["selection_id"] == sel["selection_id"]
    # the identical *unpinned* request now resolves to v2, i.e. different pins -> conflict
    clash = client.post("/selections", json=body)
    assert clash.status_code == 409 and "latest" in clash.json()["detail"]
    bad = client.post("/selections", json={"name": "x", "node_ids": [node_id(client, "5.3")], "version": 1})
    assert bad.status_code == 422

    chapter = client.post("/selections", json={"name": "ch4", "node_ids": [node_id(client, "4")]}).json()
    assert [n["section_number"] for n in chapter["nodes"]] == ["4", "4.1", "4.2", "4.3"]
    assert {n["role"] for n in chapter["nodes"][1:]} == {"descendant"}


def test_matcher_flags_identity_kept_by_number_and_title_but_body_rewritten():
    old = [_node("root", "t", ""), _node("6", "Maintenance", ""),
           _node("6.2", "Calibration", "Professional recalibration every 2 years or after any drop.", "6")]
    prev = [_prev(1, old[0]), _prev(2, old[1], 1), _prev(3, old[2], 2)]
    new = _result(old[0], old[1], _node("6.2", "Calibration",
                                        "Run the self-test from the settings menu each month.", "6"))
    m, report = match_versions(prev, new)
    assert m["6.2"].logical_id == 3 and m["6.2"].status == "modified"
    assert report["low_confidence"] == ["6.2"]
