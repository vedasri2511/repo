# CT-200 Traceability API

Backend for the Tri9T AI internship assignment. It turns the CardioTrack CT-200
manual (PDF) into a versioned, browsable section tree, lets a user pin sections
into named selections, generates QA test-case ideas from them with an LLM, and
tells the user at retrieval time whether those test cases still match the
current manual.

* Design, parsing decisions, matching strategy, prompt/validation design and
  the decision log: **[docs/APPROACH.md](docs/APPROACH.md)**
* What the PDFs actually contain (written before the parser):
  [docs/pdf_inspection_notes.md](docs/pdf_inspection_notes.md)
* Parser validation runs, before and after the fixes: [docs/validation_logs/](docs/validation_logs)

Stack: FastAPI · Pydantic v2 · SQLAlchemy 2 + SQLite · MongoDB (or a JSON file
store) · pdfplumber + Tesseract OCR · httpx.

## Setup

Python 3.11+ (developed on 3.13).

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # optional; defaults work without it
```

System packages, only for the OCR fallback/cross-check (the CT-200 PDFs have a
text layer, so everything else works without them):

```bash
sudo apt install tesseract-ocr poppler-utils      # macOS: brew install tesseract poppler
```

MongoDB (optional): set `MONGO_URI` (local or Atlas free tier). Without it,
generations go to `var/generations.json`; see the approach doc for the
trade-off.

## Run

```bash
uvicorn app.main:app --reload --port 8000
# interactive docs: http://127.0.0.1:8000/docs
```

## Environment variables

| Variable | Default | Meaning |
|---|---|---|
| `DATABASE_URL` | `sqlite:///var/ct200.db` | SQLite DB for documents, versions, tree, selections |
| `GENERATION_STORE` | `mongo` if `MONGO_URI` set, else `json` | Where generations are stored |
| `MONGO_URI` / `MONGO_DB` | `mongodb://localhost:27017` / `ct200` | MongoDB connection |
| `JSON_STORE_PATH` | `var/generations.json` | JSON store file |
| `LLM_PROVIDER` | `mock` | `mock`, `groq`, `gemini`, `openrouter` |
| `LLM_API_KEY` | – | Key for the provider |
| `LLM_MODEL` | provider default | Model id (check the provider's current model list) |
| `LLM_TIMEOUT_S` / `LLM_MAX_ATTEMPTS` | `60` / `3` | Per-call timeout, attempts incl. repair retries |
| `LLM_MOCK_SCENARIO` | `good` | Mock behaviour: `good`, `flaky`, `ungrounded`, `garbage`, `too_few` |
| `OCR_MODE` | `auto` | `auto` (OCR pages without text), `force`, `off` |
| `OCR_CROSSCHECK` | `false` | OCR every page at ingest and warn where it disagrees with the text layer |

Using a real LLM, e.g. Groq:

```bash
LLM_PROVIDER=groq LLM_API_KEY=gsk_... uvicorn app.main:app --port 8000
```

## The v1 → v2 re-ingestion flow

With the server running:

```bash
python scripts/demo_flow.py                 # Python/httpx walkthrough, prints every step
./scripts/demo_curl.sh                      # same flow with curl + jq
```

Both use a fresh document slug, so they can be re-run. What they do:

1. `POST /documents/{slug}/versions` with `data/ct200_manual.pdf` → version 1
   (plus the parser's warnings for the irregular sections).
2. Browse: top-level sections, node 4.2 with children/hash, search.
3. `POST /selections` pinned to v1 (4.1+4.2, 1.1, 2.1.1.1).
4. `POST /selections/{id}/generations` → 3–5 test cases each; a second call is
   answered from the stored generation (`reused: true`).
5. `POST /documents/{slug}/versions` with `data/ct200_manual_v2.pdf` → version 2:
   24 unchanged, 4 modified (2.1.1.1, 3.2, 4.2, 4.3), 1 added (5.3).
   Uploading the same file again is a no-op.
6. `GET /nodes/{id}/changes` for 4.2 → substantive change, `2 seconds` → `1.5 seconds`, E6 added.
7. `GET /selections/{id}` → still the exact v1 text, with `current_in_latest: false`.
8. `GET /generations?selection_id=…` → **stale** for 4.2 and 2.1.1.1 (naming the test
   cases that assert values the manual no longer states), **current** for 1.1.
9. `GET /nodes/{id}/generations` → the same, looked up by node.
10. A new selection on v2 → fresh, current test cases.

Sample output (mock LLM): [docs/demo_output_mock_llm.txt](docs/demo_output_mock_llm.txt).

Manual curl equivalents:

```bash
curl -F file=@data/ct200_manual.pdf    localhost:8000/documents/ct200/versions
curl -F file=@data/ct200_manual_v2.pdf localhost:8000/documents/ct200/versions
curl localhost:8000/documents/ct200/versions/2          # parse warnings + matching report
```

## API overview

| Method & path | Purpose |
|---|---|
| `POST /documents/{slug}/versions` | Upload a PDF as the next version (multipart `file`) |
| `GET /documents`, `GET /documents/{slug}/versions` | List documents / versions |
| `GET /documents/{slug}/versions/{n}` | Parse warnings, stats, matching report for a version |
| `GET /documents/{slug}/sections?version=` | Top-level sections (default latest) |
| `GET /documents/{slug}/search?q=&field=heading\|text\|both&version=` | Search headings/text |
| `GET /nodes/{id}?version=` | Node with children, full text, blocks, content hash, warnings |
| `GET /nodes/{id}/changes` | Changed across versions? Diff summary + severity per transition |
| `POST /selections` | Named, version-pinned selection (`node_ids` + `version`, or `items`) |
| `GET /selections`, `GET /selections/{id}` | Selections, resolved to their pinned text |
| `POST /selections/{id}/generations` | Generate test cases (`{"force": true}` to regenerate) |
| `GET /generations?selection_id=&node_id=&include_failed=` | Retrieve with staleness |
| `GET /generations/{id}?include_attempts=true` | One generation, incl. raw LLM attempts |
| `GET /nodes/{id}/generations` | Generations whose source includes the node |

Node ids are **logical** ids: the same section keeps its id across versions;
`?version=` picks which version's text you see.

## Tests

```bash
pytest -q            # 59 tests, ~35 s (the forced-OCR test needs Tesseract, else it is skipped)
python scripts/validate_parse.py data/ct200_manual.pdf data/ct200_manual_v2.pdf   # parser harness
python scripts/validate_parse.py --force-ocr data/ct200_manual.pdf                # OCR path
```

* `tests/test_parser_irregularities.py` – one test per irregularity in the PDF
  (duplicate heading, skipped level, out-of-order sections, body-size heading,
  list items vs headings, cross-references, tables, displaced hyphens,
  page-break paragraphs) plus synthetic cases (duplicate numbers, child before
  parent, orphans, split tables) and the forced-OCR run.
* `tests/test_versioning.py` – matcher rules, revision reuse on v1→v2, browse and selection API.
* `tests/test_generation.py` – malformed/partial/ungrounded LLM output, retries,
  failure storage, idempotency, Mongo store (mongomock).
* `tests/test_staleness_flow.py` – end-to-end staleness through the HTTP API.
* `tests/test_llm_providers.py` – Groq/OpenRouter/Gemini clients against canned HTTP responses.

## Layout

```
app/
  parser/      extract.py (char-level layout, tables), structure.py (hierarchy + warnings),
               ocr.py (Tesseract fallback/cross-check), normalize.py (hashing), pdf_parser.py
  services/    ingest, matching (version matcher), diff (change severity), selection,
               generation (prompt, validation, retries), llm (providers + mock),
               staleness, store (Mongo/JSON), tree (read helpers)
  api/         FastAPI routers
  models.py    SQLAlchemy models   schemas.py  Pydantic models
scripts/       demo_flow.py, demo_curl.sh, validate_parse.py, dump_pdf_layout.py
data/          ct200_manual.pdf (v1), ct200_manual_v2.pdf (v2)
docs/          APPROACH.md, inspection notes, validation logs, demo output
```
