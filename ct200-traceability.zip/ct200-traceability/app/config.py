"""Settings from environment variables (see .env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_dotenv() -> None:
    env = ROOT / ".env"
    if not env.exists():
        return
    for raw in env.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", f"sqlite:///{ROOT / 'var' / 'ct200.db'}"))
    # generation store: "mongo" (needs MONGO_URI) or "json" (file store, no server needed)
    generation_store: str = field(default_factory=lambda: os.getenv("GENERATION_STORE", "mongo" if os.getenv("MONGO_URI") else "json"))
    mongo_uri: str = field(default_factory=lambda: os.getenv("MONGO_URI", "mongodb://localhost:27017"))
    mongo_db: str = field(default_factory=lambda: os.getenv("MONGO_DB", "ct200"))
    json_store_path: str = field(default_factory=lambda: os.getenv("JSON_STORE_PATH", str(ROOT / "var" / "generations.json")))
    # LLM: groq | gemini | openrouter | mock
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "mock"))
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", ""))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", ""))
    llm_timeout_s: float = field(default_factory=lambda: float(os.getenv("LLM_TIMEOUT_S", "60")))
    llm_max_attempts: int = field(default_factory=lambda: int(os.getenv("LLM_MAX_ATTEMPTS", "3")))
    # parser
    ocr_mode: str = field(default_factory=lambda: os.getenv("OCR_MODE", "auto"))
    ocr_crosscheck: bool = field(default_factory=lambda: _bool("OCR_CROSSCHECK", False))


_load_dotenv()
_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reset_settings() -> None:
    """Re-read the environment (used by tests)."""
    global _settings
    _settings = None
