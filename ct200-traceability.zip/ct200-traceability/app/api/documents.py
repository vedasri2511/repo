from __future__ import annotations

from typing import Literal, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, Response, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_session
from app.models import Document, DocumentVersion
from app.schemas import IngestResponse, NodeRef, SearchHit, VersionReport, VersionSummary
from app.services import tree
from app.services.ingest import ingest_bytes

router = APIRouter(prefix="/documents", tags=["documents"])


def version_summary(v: DocumentVersion) -> VersionSummary:
    return VersionSummary(
        version=v.version_number, document_version_id=v.id, source_filename=v.source_filename,
        file_sha256=v.file_sha256, title=v.title, ingested_at=v.ingested_at,
        node_count=len(v.entries), warning_count=len(v.parse_warnings) + sum(len(e.warnings) for e in v.entries))


def _changes(v: DocumentVersion) -> dict:
    r = dict(v.matching_report or {})
    r.pop("logical_ids", None)
    return r


@router.post("/{slug}/versions", response_model=IngestResponse, status_code=201,
             summary="Ingest a PDF as the next version of the document")
async def upload_version(slug: str, response: Response, file: UploadFile = File(...),
                         session: Session = Depends(get_session)):
    data = await file.read()
    if not data.startswith(b"%PDF"):
        raise HTTPException(422, "uploaded file is not a PDF")
    res = ingest_bytes(session, slug, data, file.filename or "upload.pdf")
    if not res.created:
        response.status_code = 200  # identical to latest version: nothing new stored
    return IngestResponse(created=res.created, document=slug, version=version_summary(res.version),
                          changes_vs_previous=_changes(res.version))


@router.get("", summary="List documents")
def list_documents(session: Session = Depends(get_session)):
    return [{"document": d.slug, "title": d.title, "versions": [v.version_number for v in d.versions]}
            for d in session.scalars(select(Document))]


@router.get("/{slug}/versions", response_model=list[VersionSummary])
def list_versions(slug: str, session: Session = Depends(get_session)):
    doc = tree.get_document(session, slug)
    return [version_summary(v) for v in doc.versions]


@router.get("/{slug}/versions/{version}", response_model=VersionReport,
            summary="Parse report: warnings, stats and what changed versus the previous version")
def version_report(slug: str, version: int, session: Session = Depends(get_session)):
    doc = tree.get_document(session, slug)
    v = tree.resolve_version(session, doc.id, version)
    s = version_summary(v)
    return VersionReport(**s.model_dump(), parse_warnings=v.parse_warnings, parse_stats=v.parse_stats,
                         matching_report=_changes(v),
                         node_warnings={e.section_key: e.warnings for e in v.entries if e.warnings})


@router.get("/{slug}/sections", response_model=list[NodeRef], summary="Top-level sections")
def top_level(slug: str, version: Optional[int] = Query(None, description="default: latest"),
              session: Session = Depends(get_session)):
    doc = tree.get_document(session, slug)
    v = tree.resolve_version(session, doc.id, version)
    root = tree.root_entry(session, v.id)
    out = []
    for e in tree.children(session, v.id, root.logical_node_id):
        out.append(NodeRef(node_id=e.logical_node_id, section_number=e.section_number, title=e.revision.title,
                           level=e.level, change_status=e.change_status,
                           has_children=bool(tree.children(session, v.id, e.logical_node_id))))
    return out


@router.get("/{slug}/search", response_model=list[SearchHit])
def search(slug: str, q: str = Query(..., min_length=1), version: Optional[int] = None,
           field: Literal["heading", "text", "both"] = "both", limit: int = Query(50, le=200),
           session: Session = Depends(get_session)):
    doc = tree.get_document(session, slug)
    v = tree.resolve_version(session, doc.id, version)
    return tree.search(session, v.id, q, field, limit)
