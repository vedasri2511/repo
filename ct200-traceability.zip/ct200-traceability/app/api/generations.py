from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Response
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.db import get_session
from app.schemas import GenerateRequest
from app.services import generation as gen_svc
from app.services import selection as sel_svc
from app.services import staleness, tree
from app.services.llm import LLMError
from app.services.store import get_store

router = APIRouter(tags=["generations"])


def present(session: Session, gen: dict, with_attempts: bool = False) -> dict:
    out = {
        "generation_id": gen["_id"],
        "status": gen["status"],
        "selection_id": gen["selection_id"],
        "selection_name": gen["selection_name"],
        "created_at": gen["created_at"],
        "provider": gen["provider"], "model": gen["model"], "prompt_version": gen["prompt_version"],
        "supersedes": gen.get("supersedes"),
        "warnings": gen.get("warnings", []),
        "error": gen.get("error"),
        "sources": [{k: s[k] for k in ("node_id", "section_number", "title", "version",
                                       "revision_id", "content_hash", "role")} for s in gen["sources"]],
        "test_cases": gen.get("test_cases", []),
    }
    if gen["status"].startswith("accepted"):
        out["staleness"] = staleness.evaluate(session, gen)
    if with_attempts:
        out["attempts"] = gen.get("attempts", [])
    return out


@router.post("/selections/{selection_id}/generations", status_code=201,
             summary="Generate 3-5 QA test case ideas for a selection")
def generate(selection_id: int, response: Response, body: GenerateRequest = Body(default=GenerateRequest()),
             session: Session = Depends(get_session)):
    sel_svc.get_selection(session, selection_id)  # 404 early
    try:
        gen, reused = gen_svc.generate(session, selection_id, force=body.force)
    except gen_svc.GenerationInProgress as e:
        raise HTTPException(409, str(e))
    except gen_svc.GenerationFailed as e:
        return JSONResponse(status_code=502, content={
            "detail": str(e), "generation_id": e.gen_id,
            "hint": f"GET /generations/{e.gen_id}?include_attempts=true for the raw responses"})
    except LLMError as e:  # configuration problems (missing key, unknown provider)
        raise HTTPException(503, str(e))
    if reused:
        response.status_code = 200
    return {"reused": reused, **present(session, gen)}


@router.get("/generations", summary="Previously generated test cases, with staleness, by selection or node")
def list_generations(selection_id: Optional[int] = None, node_id: Optional[int] = None,
                     include_failed: bool = False, session: Session = Depends(get_session)):
    if selection_id is None and node_id is None:
        raise HTTPException(422, "pass selection_id and/or node_id")
    if node_id is not None:
        tree.logical_node(session, node_id)
    gens = get_store().find(selection_id=selection_id, node_id=node_id)
    if not include_failed:
        gens = [g for g in gens if g["status"].startswith("accepted")]
    return [present(session, g) for g in gens]


@router.get("/generations/{generation_id}")
def get_generation(generation_id: str, include_attempts: bool = Query(False),
                   session: Session = Depends(get_session)):
    gen = get_store().get(generation_id)
    if gen is None:
        raise HTTPException(404, f"generation {generation_id} not found")
    return present(session, gen, with_attempts=include_attempts)


@router.get("/nodes/{node_id}/generations", summary="Generations whose source text includes this node")
def generations_for_node(node_id: int, session: Session = Depends(get_session)):
    return list_generations(selection_id=None, node_id=node_id, include_failed=False, session=session)
