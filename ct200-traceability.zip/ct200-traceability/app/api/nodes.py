from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db import get_session
from app.schemas import Block, NodeDetail, NodeRef
from app.services import tree

router = APIRouter(prefix="/nodes", tags=["nodes"])


def node_detail(session: Session, node_id: int, version: Optional[int]) -> NodeDetail:
    ln = tree.logical_node(session, node_id)
    doc_version = tree.resolve_version(session, ln.document_id, version)
    e = tree.entry(session, doc_version.id, node_id)
    if e is None:
        present = [v.version_number for v, _ in tree.history(session, node_id)]
        raise HTTPException(404, f"node {node_id} does not exist in version {doc_version.version_number}; "
                                 f"present in versions {present}")
    rev = e.revision
    parent = None
    if e.parent_logical_node_id is not None:
        pe = tree.entry(session, doc_version.id, e.parent_logical_node_id)
        parent = NodeRef(node_id=pe.logical_node_id, section_number=pe.section_number,
                         title=pe.revision.title, level=pe.level, change_status=pe.change_status)
    kids = [NodeRef(node_id=c.logical_node_id, section_number=c.section_number, title=c.revision.title,
                    level=c.level, change_status=c.change_status,
                    has_children=bool(tree.children(session, doc_version.id, c.logical_node_id)))
            for c in tree.children(session, doc_version.id, node_id)]
    return NodeDetail(
        node_id=node_id, document=doc_version.document.slug, version=doc_version.version_number,
        section_key=e.section_key, section_number=e.section_number, title=rev.title,
        heading=f"{e.section_number} {rev.title}" if e.section_number else rev.title,
        level=e.level, depth=e.depth, parent=parent, children=kids, body_text=rev.body_text,
        blocks=[Block(**b) for b in rev.blocks], content_hash=rev.content_hash, revision_id=rev.id,
        pages=list(range(e.page_start, e.page_end + 1)), change_status=e.change_status,
        match_rule=e.match_rule, cross_references=e.refs, warnings=e.warnings)


@router.get("/{node_id}", response_model=NodeDetail,
            summary="A node with its children, full text and content hash")
def get_node(node_id: int, version: Optional[int] = Query(None, description="default: latest"),
             session: Session = Depends(get_session)):
    return node_detail(session, node_id, version)


@router.get("/{node_id}/changes", summary="Has this node changed across versions? With diff summary")
def node_changes(node_id: int, session: Session = Depends(get_session)):
    return tree.change_report(session, node_id)
