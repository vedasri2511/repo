from __future__ import annotations

from fastapi import APIRouter, Depends, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_session
from app.models import Selection
from app.schemas import PinnedNode, SelectionCreate, SelectionOut
from app.services import selection as sel_svc
from app.services import tree

router = APIRouter(prefix="/selections", tags=["selections"])


def selection_out(session: Session, sel: Selection, created: bool | None = None) -> SelectionOut:
    latest = tree.resolve_version(session, sel.document_id, None)
    nodes = []
    for n in sel_svc.resolve(session, sel):
        cur = tree.entry(session, latest.id, n["node_id"])
        nodes.append(PinnedNode(
            node_id=n["node_id"], version=n["version"], section_number=n["section_number"], title=n["title"],
            revision_id=n["revision_id"], content_hash=n["content_hash"], role=n["role"],
            body_text=n["body_text"], latest_version=latest.version_number,
            current_in_latest=bool(cur and cur.revision.content_hash == n["content_hash"])))
    doc = tree.version_by_id(session, sel.items[0].document_version_id).document
    return SelectionOut(selection_id=sel.id, name=sel.name, document=doc.slug,
                        include_descendants=sel.include_descendants, created_at=sel.created_at,
                        created=created, nodes=nodes)


@router.post("", response_model=SelectionOut, status_code=201,
             summary="Create a named, version-pinned selection (idempotent for identical name+nodes)")
def create(body: SelectionCreate, response: Response, session: Session = Depends(get_session)):
    items = [sel_svc.ItemRequest(node_id=i) for i in body.node_ids] + \
            [sel_svc.ItemRequest(node_id=i.node_id, version=i.version) for i in body.items]
    sel, created = sel_svc.create_selection(session, body.document, body.name, items,
                                            body.version, body.include_descendants)
    if not created:
        response.status_code = 200
    return selection_out(session, sel, created)


@router.get("", summary="List selections")
def list_selections(session: Session = Depends(get_session)):
    return [{"selection_id": s.id, "name": s.name, "created_at": s.created_at,
             "items": [{"node_id": i.logical_node_id,
                        "version": tree.version_by_id(session, i.document_version_id).version_number}
                       for i in s.items]}
            for s in session.scalars(select(Selection).order_by(Selection.id))]


@router.get("/{selection_id}", response_model=SelectionOut,
            summary="A selection resolved to the exact text it was pinned to")
def get(selection_id: int, session: Session = Depends(get_session)):
    return selection_out(session, sel_svc.get_selection(session, selection_id))
