"""Pydantic request/response models for the API."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class VersionSummary(BaseModel):
    version: int
    document_version_id: int
    source_filename: str
    file_sha256: str
    title: str
    ingested_at: datetime
    node_count: int
    warning_count: int


class IngestResponse(BaseModel):
    created: bool = Field(description="false when the uploaded file is identical to the latest version")
    document: str
    version: VersionSummary
    changes_vs_previous: dict[str, Any]


class VersionReport(VersionSummary):
    parse_warnings: list[str]
    parse_stats: dict[str, Any]
    matching_report: dict[str, Any]
    node_warnings: dict[str, list[str]]


class NodeRef(BaseModel):
    node_id: int
    section_number: Optional[str]
    title: str
    level: int
    change_status: str
    has_children: bool = False


class Block(BaseModel):
    kind: str
    page: int
    text: Optional[str] = None
    items: Optional[list[str]] = None
    ordered: Optional[bool] = None
    rows: Optional[list[list[str]]] = None


class NodeDetail(BaseModel):
    node_id: int
    document: str
    version: int
    section_key: str
    section_number: Optional[str]
    title: str
    heading: str
    level: int = Field(description="depth implied by the section number (2.1.1.1 -> 4)")
    depth: int = Field(description="actual depth in the reconstructed tree")
    parent: Optional[NodeRef]
    children: list[NodeRef]
    body_text: str
    blocks: list[Block]
    content_hash: str
    revision_id: int
    pages: list[int]
    change_status: str
    match_rule: str
    cross_references: list[str]
    warnings: list[str]


class SearchHit(BaseModel):
    node_id: int
    section_number: Optional[str]
    title: str
    matched_in: Literal["heading", "text"]
    snippet: str


class SelectionItemIn(BaseModel):
    node_id: int
    version: Optional[int] = Field(None, description="defaults to the request-level version, then latest")


class SelectionCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    document: str = "ct200"
    node_ids: list[int] = Field(default_factory=list)
    items: list[SelectionItemIn] = Field(default_factory=list)
    version: Optional[int] = Field(None, description="version to pin node_ids to; default latest")
    include_descendants: bool = True

    @model_validator(mode="after")
    def _one_of(self):
        if not self.node_ids and not self.items:
            raise ValueError("provide node_ids or items")
        return self


class PinnedNode(BaseModel):
    node_id: int
    version: int
    section_number: Optional[str]
    title: str
    revision_id: int
    content_hash: str
    role: Literal["selected", "descendant"]
    body_text: str
    latest_version: Optional[int] = None
    current_in_latest: Optional[bool] = Field(None, description="does the latest version still have this exact text?")


class SelectionOut(BaseModel):
    selection_id: int
    name: str
    document: str
    include_descendants: bool
    created_at: datetime
    created: Optional[bool] = None
    nodes: list[PinnedNode]


class GenerateRequest(BaseModel):
    force: bool = Field(False, description="generate again even if an accepted generation exists for identical input")
