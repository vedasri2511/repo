from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.api import documents, generations, nodes, selections
from app.db import init_engine
from app.services import selection as sel_svc
from app.services.tree import NotFound


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_engine()
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="CT-200 Traceability API",
        description="Versioned document tree, version-pinned selections, LLM test-case generation "
                    "and staleness detection for the CardioTrack CT-200 manual.",
        version="1.0.0",
        lifespan=lifespan,
    )
    app.include_router(documents.router)
    app.include_router(nodes.router)
    app.include_router(selections.router)
    app.include_router(generations.router)

    @app.exception_handler(NotFound)
    async def _nf(_: Request, exc: NotFound):
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    @app.exception_handler(sel_svc.Conflict)
    async def _conflict(_: Request, exc: sel_svc.Conflict):
        return JSONResponse(status_code=409, content={"detail": str(exc)})

    @app.exception_handler(sel_svc.Invalid)
    async def _invalid(_: Request, exc: sel_svc.Invalid):
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.get("/health", tags=["meta"])
    def health():
        return {"status": "ok"}

    return app


app = create_app()
