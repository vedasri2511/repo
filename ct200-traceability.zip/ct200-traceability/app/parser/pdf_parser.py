"""CT-200 manual parsing pipeline.

    PDF ──► per page: text layer present?  ── yes ──► character-level layout (extract.py)
                                            └─ no ──► Tesseract OCR lines (ocr.py), flagged
        ──► hierarchy reconstruction + anomaly warnings (structure.py)
        ──► optional OCR cross-check of every text-layer page

ocr_mode:
  "auto"  – OCR only pages whose text layer has fewer than MIN_LAYER_CHARS glyphs
  "force" – OCR every page (used to test the OCR path on this PDF)
  "off"   – never OCR; a page without text produces a warning instead
"""
from __future__ import annotations

from pathlib import Path

import pdfplumber

from app.parser.extract import PageLayout, extract_page
from app.parser.model import ParseResult
from app.parser.structure import build_tree

MIN_LAYER_CHARS = 20
CROSSCHECK_MIN_AGREEMENT = 0.9


def parse_pdf(path: str | Path, ocr_mode: str = "auto", ocr_crosscheck: bool = False) -> ParseResult:
    path = str(path)
    layouts: list[PageLayout] = []
    notes: list[str] = []
    with pdfplumber.open(path) as pdf:
        for page_no, page in enumerate(pdf.pages, start=1):
            layout = extract_page(page, page_no)
            needs_ocr = ocr_mode == "force" or (ocr_mode == "auto" and layout.total_chars < MIN_LAYER_CHARS)
            if needs_ocr:
                from app.parser import ocr

                if ocr.ocr_available():
                    layout = PageLayout(page=page_no, height=float(page.height), method="ocr",
                                        items=ocr.ocr_page_lines(path, page_no))
                else:
                    notes.append(f"page {page_no}: OCR needed but Tesseract is not installed; page content missing")
            elif layout.total_chars < MIN_LAYER_CHARS:
                notes.append(f"page {page_no}: no usable text layer and OCR is off; page content missing")
            layouts.append(layout)

    result = build_tree(layouts)
    result.warnings.extend(notes)

    if ocr_crosscheck:
        from app.parser import ocr

        if not ocr.ocr_available():
            result.warnings.append("OCR cross-check requested but Tesseract is not installed; skipped")
        else:
            checks = []
            for layout in layouts:
                if layout.method != "text_layer":
                    continue
                text = "\n".join(
                    it.text if hasattr(it, "text") else " ".join(c for r in it.rows for c in r)
                    for it in layout.items if hasattr(it, "text") or hasattr(it, "rows"))
                check = ocr.cross_check(path, layout.page, text)
                checks.append(check)
                if check["agreement"] < CROSSCHECK_MIN_AGREEMENT:
                    result.warnings.append(
                        f"page {layout.page}: OCR and text layer agree on only "
                        f"{check['agreement']:.0%} of words; inspect this page")
            result.stats["ocr_crosscheck"] = checks

    result.stats.update(
        pages=len(layouts),
        nodes=len(result.nodes) - 1,
        glyphs_total=sum(l.total_chars for l in layouts),
        glyphs_assigned=sum(l.assigned_chars for l in layouts),
    )
    return result
