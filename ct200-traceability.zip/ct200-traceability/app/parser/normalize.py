"""Text normalization and hashing.

Hashes must not depend on layout (line breaks, page breaks, paragraph
segmentation), only on the words and symbols a reader sees. Two different
normalizations exist on purpose:

* ``normalize_text`` keeps case and symbols such as ≥, ±, –, because a QA
  engineer cares whether "≥ 140" became "> 140". This is what gets hashed.
* ``loose_text`` is lowercase ASCII-ish and is only used for fuzzy *matching*
  (quote grounding, OCR cross-checks), never for hashing.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata

# Characters the PDF uses that have a plain equivalent with identical meaning.
_EQUIVALENT_CHARS = {
    "‑": "-",  # non-breaking hyphen (rendered from a fallback font in the PDF)
    "­": "",   # soft hyphen
    " ": " ",  # nbsp
    " ": " ",  # thin space
    " ": " ",
    "‘": "'", "’": "'", "“": '"', "”": '"',
}

_WS = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    """Canonical form used for content hashes and stored body text."""
    text = unicodedata.normalize("NFC", text)
    for src, dst in _EQUIVALENT_CHARS.items():
        text = text.replace(src, dst)
    return _WS.sub(" ", text).strip()


def loose_text(text: str) -> str:
    """Aggressive form for fuzzy comparison only (never hashed)."""
    text = normalize_text(text).lower()
    text = text.replace("–", "-").replace("—", "-")
    text = re.sub(r"[^\w%±≥≤<>=.\- ]", " ", text)
    return _WS.sub(" ", text).strip()


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def content_hash(title: str, body: str) -> str:
    """Hash of a node's *own* content: heading title + body (not children).

    Section numbers are deliberately excluded so a pure renumbering does not
    look like a content change; the matcher reports renumbering separately.
    """
    return sha256(normalize_text(title) + "\n" + normalize_text(body))
