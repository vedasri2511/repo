"""Hierarchy reconstruction for the CT-200 manual.

Input: per-page layouts (lines, tables, figures in reading order).
Output: a ParseResult tree with warnings for every structural anomaly.

Rules (each one exists because of something observed in the PDF, see
docs/pdf_inspection_notes.md):

* Section *numbers* decide level and parent. Font size does not: 3.2 and
  2.1.1.1 are set at body size.
* A heading is a line at the left margin that starts with a section number
  and is bold. Numbered lines that are indented or not bold are list items
  ("1. Normal: ..." in 3.3). For OCR lines (no font info) the margin, length
  and punctuation decide instead.
* Parent = the longest numeric prefix that exists *anywhere* in the document
  (two passes), so a missing intermediate level (2.1.1) attaches 2.1.1.1 to
  2.1, and a child printed before its parent still finds it. Both cases are
  warned about, never silently fixed.
* Reading order is preserved. 3.4 printed before 3.3 stays in that order
  and is flagged; nothing is re-sorted behind the user's back.
* A repeated section number gets a distinct key ("4.2#2") and a warning.
  A repeated *title* under different numbers ("Error Codes") is legitimate
  and keeps distinct keys.
* A paragraph that runs to the bottom of a page continues on the next page.
* Every glyph on a page must land in a line or table cell; otherwise the
  document gets a coverage warning.
"""
from __future__ import annotations

import re
import statistics
from collections import Counter, defaultdict
from typing import Optional

from app.parser.extract import FigureItem, Line, PageLayout, TableItem
from app.parser.model import Block, ParsedNode, ParseResult

HEADING_RE = re.compile(r"^(?P<num>\d{1,2}(?:\.\d{1,3}){0,5})\.?\s+(?P<title>[A-Z(].{0,120})$")
LIST_RE = re.compile(r"^(?P<marker>\d{1,2}[.)]|[a-z][.)]|[•▪◦●\-–*])\s+(?P<text>\S.*)$")
REF_RE = re.compile(
    r"\b(?:see|Section|section|Sections|sections)\s+"
    r"(\d+(?:\.\d+)+(?:\s*(?:,|and|&)\s*\d+(?:\.\d+)+)*)"
)
CAPTION_RE = re.compile(r"^(Figure|Fig\.)\s*\d*", re.I)

PAGE_BOTTOM_ZONE = 72.0   # pt from the page bottom: a paragraph ending here may continue
PARA_GAP = 6.0            # pt of white space between lines that still counts as the same paragraph
MARGIN_TOL = 3.0
INDENT_MIN = 5.0


def _left_margin(lines: list[Line]) -> float:
    xs = Counter(round(l.x0) for l in lines)
    return float(xs.most_common(1)[0][0]) if xs else 0.0


def _is_heading(line: Line, margin: float) -> Optional[re.Match]:
    m = HEADING_RE.match(line.text)
    if not m or line.x0 > margin + MARGIN_TOL:
        return None
    if line.bold is None:  # OCR: no font info
        if len(line.text) > 80 or line.text.rstrip().endswith((".", ",", ";", ":")):
            return None
        return m
    return m if line.bold else None


class _Builder:
    def __init__(self, layouts: list[PageLayout]):
        self.layouts = layouts
        self.result_warnings: list[str] = []
        self.nodes: list[ParsedNode] = []
        self.title_lines: list[str] = []
        self.root = ParsedNode(key="root", number=None, title="", level=0, parent_key=None,
                               order_index=0, page_start=1, page_end=1)
        self.nodes.append(self.root)
        self.current = self.root
        self.para: list[str] = []
        self.para_page = 1
        self.list_block: Optional[Block] = None
        self.list_text_x: float = 0.0
        self.last_line: Optional[Line] = None
        self.page_height = {l.page: l.height for l in layouts}
        all_lines = [it for l in layouts for it in l.items if isinstance(it, Line)]
        self.margin = _left_margin(all_lines)
        self.ocr_pages = {l.page for l in layouts if l.method == "ocr"}
        self.page_break_joins: list[tuple[str, int, int]] = []

    # -- block helpers -------------------------------------------------------
    def flush_para(self):
        if self.para:
            self.current.blocks.append(Block(kind="paragraph", page=self.para_page,
                                             text=" ".join(self.para)))
            self.para = []
        self.list_block = None

    def touch(self, page: int):
        self.current.page_end = max(self.current.page_end, page)
        if page in self.ocr_pages:
            msg = f"content on page {page} came from OCR (no text layer): symbols such as ≥/≤ and list numbers may be misread"
            if msg not in self.current.warnings:
                self.current.warnings.append(msg)

    def continues_paragraph(self, line: Line, first_on_page: bool) -> bool:
        prev = self.last_line
        if not self.para or prev is None:
            return False
        aligned = (abs(line.x0 - self.margin) <= MARGIN_TOL + 2
                   or abs(line.x0 - prev.x0) <= MARGIN_TOL)  # indented block (e.g. OCR'd table rows)
        if not aligned:
            return False
        if prev.page == line.page:
            return line.top - prev.bottom <= PARA_GAP
        # page break: continue only if the previous paragraph ran to the bottom
        # of its page and this is the first thing on the next page
        return (line.page == prev.page + 1 and first_on_page
                and prev.bottom >= self.page_height[prev.page] - PAGE_BOTTOM_ZONE)

    # -- main loop -----------------------------------------------------------
    def run(self) -> ParseResult:
        seen_heading = False
        for layout in self.layouts:
            first_on_page = True
            pending_figure: Optional[Block] = None
            for item in layout.items:
                if isinstance(item, TableItem):
                    self.add_table(item, first_on_page)
                    self.last_line = None
                    first_on_page = False
                    continue
                if isinstance(item, FigureItem):
                    self.flush_para()
                    pending_figure = Block(kind="figure", page=item.page, text="")
                    self.current.blocks.append(pending_figure)
                    self.touch(item.page)
                    first_on_page = False
                    continue

                line: Line = item
                if pending_figure is not None:
                    if CAPTION_RE.match(line.text):
                        pending_figure.text = line.text
                        pending_figure = None
                        first_on_page = False
                        continue
                    self.current.warnings.append(f"figure on page {item.page} has no caption")
                    pending_figure = None

                m = _is_heading(line, self.margin)
                if not seen_heading and not m:
                    if (line.size or 0) >= 18 or line.source == "ocr":
                        self.title_lines.append(line.text)
                    else:
                        self.add_text(line, first_on_page)
                        self.root.warnings.append(f"text before first section on page {line.page}: {line.text[:60]!r}")
                    first_on_page = False
                    continue
                if m:
                    seen_heading = True
                    self.add_heading(line, m)
                elif line.bold and HEADING_RE.match(line.text) is None and abs(line.x0 - self.margin) <= MARGIN_TOL \
                        and len(line.text) < 80 and not self.para:
                    self.current.warnings.append(
                        f"bold line not recognised as a numbered heading, kept as text: {line.text!r}")
                    self.add_text(line, first_on_page)
                else:
                    if (HEADING_RE.match(line.text) and line.bold is False
                            and abs(line.x0 - self.margin) <= MARGIN_TOL and not self.para):
                        self.current.warnings.append(
                            f"numbered line at the margin is not bold, treated as text: {line.text[:60]!r}")
                    self.add_text(line, first_on_page)
                first_on_page = False
            if pending_figure is not None:
                self.current.warnings.append(f"figure on page {layout.page} has no caption")
        self.flush_para()
        self.root.title = " ".join(self.title_lines).strip()
        if not self.root.title:
            self.result_warnings.append("no document title found before the first section")
        self.link_parents()
        self.check_sequences()
        self.check_heading_styles()
        self.check_titles()
        self.collect_refs()
        self.check_coverage()
        return ParseResult(title=self.root.title, nodes=self.nodes, warnings=self.result_warnings,
                           page_methods={l.page: l.method for l in self.layouts})

    def add_heading(self, line: Line, m: re.Match):
        self.flush_para()
        number = m.group("num")
        key = number
        existing = [n for n in self.nodes if n.number == number]
        warnings = []
        if existing:
            key = f"{number}#{len(existing) + 1}"
            warnings.append(f"section number {number} appears more than once; this occurrence keyed as {key}")
        node = ParsedNode(key=key, number=number, title=m.group("title").strip(),
                          level=number.count(".") + 1, parent_key=None,
                          order_index=len(self.nodes), page_start=line.page, page_end=line.page,
                          warnings=warnings, heading_size=line.size)
        self.nodes.append(node)
        self.current = node
        self.last_line = line
        self.touch(line.page)

    def add_text(self, line: Line, first_on_page: bool):
        indented = line.x0 > self.margin + INDENT_MIN
        lm = LIST_RE.match(line.text)
        if lm and indented:
            if self.list_block is None:
                self.flush_para()
                self.list_block = Block(kind="list", page=line.page,
                                        ordered=lm.group("marker")[0].isalnum())
                self.current.blocks.append(self.list_block)
            self.list_block.items.append(line.text)
            # x where the item text starts, to recognise wrapped continuation lines
            self.list_text_x = line.x0 + (line.x1 - line.x0) * len(lm.group("marker")) / max(len(line.text), 1)
        elif self.list_block is not None and indented and self.last_line is not None \
                and line.top - self.last_line.bottom <= PARA_GAP + 4:
            self.list_block.items[-1] += " " + line.text
        else:
            if self.list_block is not None:
                self.list_block = None
            if not self.continues_paragraph(line, first_on_page):
                self.flush_para()
                self.para_page = line.page
            elif self.last_line is not None and line.page != self.last_line.page:
                self.page_break_joins.append((self.current.key, self.last_line.page, line.page))
            self.para.append(line.text)
        self.last_line = line
        self.touch(line.page)

    def add_table(self, item: TableItem, first_on_page: bool):
        self.flush_para()
        prev = self.current.blocks[-1] if self.current.blocks else None
        if (prev is not None and prev.kind == "table" and first_on_page
                and prev.page == item.page - 1 and len(prev.rows[0]) == len(item.rows[0])):
            rows = item.rows[1:] if item.rows[0] == prev.rows[0] else item.rows
            prev.rows.extend(rows)
            self.current.warnings.append(f"table continued from page {prev.page} to {item.page}; merged")
        else:
            widths = {len(r) for r in item.rows}
            if len(widths) > 1:
                self.current.warnings.append(f"table on page {item.page} has ragged rows {sorted(widths)}")
            self.current.blocks.append(Block(kind="table", page=item.page, rows=item.rows))
        self.touch(item.page)

    # -- post-processing -----------------------------------------------------
    def link_parents(self):
        first_by_number: dict[str, ParsedNode] = {}
        for n in self.nodes[1:]:
            first_by_number.setdefault(n.number, n)
        for n in self.nodes[1:]:
            parts = n.number.split(".")
            parent = self.root
            for cut in range(len(parts) - 1, 0, -1):
                cand = first_by_number.get(".".join(parts[:cut]))
                if cand is not None:
                    parent = cand
                    break
            expected_parent = ".".join(parts[:-1]) if len(parts) > 1 else None
            if expected_parent and parent.number != expected_parent:
                where = f"nearest existing ancestor {parent.number}" if parent is not self.root else "the document root"
                n.warnings.append(f"numbering skips a level: {expected_parent} does not exist; "
                                  f"attached to {where}")
            if parent is not self.root and parent.order_index > n.order_index:
                n.warnings.append(f"appears before its parent {parent.number} in reading order")
            n.parent_key = parent.key
            parent.children.append(n.key)
        by_key = {n.key: n for n in self.nodes}
        for n in self.nodes[1:]:
            d, p = 0, n
            while p.parent_key is not None:
                d += 1
                p = by_key[p.parent_key]
            n.depth = d

    def check_sequences(self):
        by_key = {n.key: n for n in self.nodes}
        for parent in self.nodes:
            direct = [by_key[k] for k in parent.children
                      if by_key[k].level == (parent.level + 1) and "#" not in by_key[k].key]
            nums = [int(c.number.split(".")[-1]) for c in direct]
            for prev, cur, node in zip(nums, nums[1:], direct[1:]):
                if cur < prev:
                    node.warnings.append(
                        f"out of sequence: {node.number} appears after "
                        f"{direct[nums.index(prev)].number} in the document; reading order kept")
            if nums:
                missing = sorted(set(range(1, max(nums) + 1)) - set(nums))
                for m in missing:
                    label = f"{parent.number}.{m}" if parent.number else str(m)
                    target = parent if parent is not self.root else self.root
                    msg = f"section {label} is missing from the numbering sequence"
                    (target.warnings if target is not self.root else self.result_warnings).append(msg)

    def check_heading_styles(self):
        sizes = defaultdict(list)
        for n in self.nodes[1:]:
            if n.heading_size:
                sizes[n.level].append(n.heading_size)
        for n in self.nodes[1:]:
            if not n.heading_size or len(sizes[n.level]) < 3:
                continue
            usual = statistics.mode(sizes[n.level])
            if abs(n.heading_size - usual) > 0.5:
                n.warnings.append(f"heading set at {n.heading_size}pt, other level-{n.level} headings use "
                                  f"{usual}pt; level taken from numbering, not font size")

    def check_titles(self):
        by_title = defaultdict(list)
        for n in self.nodes[1:]:
            by_title[n.title.lower()].append(n)
        for group in by_title.values():
            if len(group) > 1:
                for n in group:
                    others = ", ".join(o.number for o in group if o is not n)
                    n.warnings.append(f"heading title also used by section {others} (distinct node)")

    def collect_refs(self):
        numbers = {n.number for n in self.nodes[1:]}
        for n in self.nodes[1:]:
            for m in REF_RE.finditer(n.body_text):
                for ref in re.findall(r"\d+(?:\.\d+)+", m.group(1)):
                    if ref not in n.refs:
                        n.refs.append(ref)
                    if ref not in numbers:
                        n.warnings.append(f"cross-reference to section {ref}, which does not exist")

    def check_coverage(self):
        for layout in self.layouts:
            if layout.method != "text_layer":
                continue
            diff = layout.total_chars - layout.assigned_chars
            if diff:
                self.result_warnings.append(
                    f"page {layout.page}: {abs(diff)} glyphs {'not assigned to any block' if diff > 0 else 'assigned twice'}")


def build_tree(layouts: list[PageLayout]) -> ParseResult:
    b = _Builder(layouts)
    result = b.run()
    result.stats["paragraphs_joined_across_pages"] = [
        {"node": k, "from_page": a, "to_page": z} for k, a, z in b.page_break_joins]
    return result
