"""Tesseract OCR: fallback for pages without a text layer, plus a cross-check
that compares OCR output with the text layer page by page.

OCR is *not* the primary source for this manual. Tests on the CT-200 PDF showed
Tesseract turning "≥ 140" into "= 140" and losing list numbers, i.e. silently
changing safety thresholds, and it gives no font weight or size. The embedded
text layer is exact, so OCR is used where it adds information:

* a page with (almost) no extractable characters is OCR'd and its lines are
  marked ``source="ocr"`` so every node built from them carries a warning;
* ``cross_check`` reports pages where OCR and the text layer disagree, which
  catches text-layer problems such as missing ToUnicode maps, invisible text
  or glyph-substitution garbage that would otherwise go unnoticed.
"""
from __future__ import annotations

from functools import lru_cache

from app.parser.extract import Line
from app.parser.normalize import loose_text

DPI = 300
PT_PER_PX = 72.0 / DPI


@lru_cache(maxsize=8)
def _render(pdf_path: str, page_no: int):
    from pdf2image import convert_from_path

    return convert_from_path(pdf_path, dpi=DPI, first_page=page_no, last_page=page_no)[0]


def ocr_available() -> bool:
    try:
        import pytesseract

        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def ocr_page_lines(pdf_path: str, page_no: int) -> list[Line]:
    import pytesseract

    image = _render(pdf_path, page_no)
    data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
    groups: dict[tuple, list[int]] = {}
    for i, word in enumerate(data["text"]):
        if word.strip() and float(data["conf"][i]) >= 0:
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            groups.setdefault(key, []).append(i)
    lines = []
    for idxs in groups.values():
        top = min(data["top"][i] for i in idxs) * PT_PER_PX
        bottom = max(data["top"][i] + data["height"][i] for i in idxs) * PT_PER_PX
        lines.append(Line(
            page=page_no, top=top, bottom=bottom,
            x0=min(data["left"][i] for i in idxs) * PT_PER_PX,
            x1=max(data["left"][i] + data["width"][i] for i in idxs) * PT_PER_PX,
            text=" ".join(data["text"][i] for i in idxs),
            bold=None, size=None, source="ocr",
        ))
    return sorted(lines, key=lambda l: l.top)


def cross_check(pdf_path: str, page_no: int, text_layer_text: str) -> dict:
    """Word-level agreement between OCR and the text layer for one page."""
    import pytesseract

    ocr_words = loose_text(pytesseract.image_to_string(_render(pdf_path, page_no))).split()
    layer_words = loose_text(text_layer_text).split()
    if not layer_words:
        return {"page": page_no, "ocr_words": len(ocr_words), "agreement": 0.0}
    layer_set = set(layer_words)
    ocr_set = set(ocr_words)
    recall = len(layer_set & ocr_set) / len(layer_set)
    return {
        "page": page_no,
        "text_layer_words": len(layer_words),
        "ocr_words": len(ocr_words),
        "agreement": round(recall, 3),
        "only_in_text_layer": sorted(layer_set - ocr_set)[:15],
        "only_in_ocr": sorted(ocr_set - layer_set)[:15],
    }
