"""Data structures produced by the parser (independent of the database)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from app.parser.normalize import content_hash, normalize_text


@dataclass
class Block:
    kind: str  # "paragraph" | "list" | "table" | "figure"
    page: int
    text: str = ""                                     # paragraph / figure caption
    items: list[str] = field(default_factory=list)     # list items
    ordered: bool = False
    rows: list[list[str]] = field(default_factory=list)  # table rows, first row = header

    def render(self) -> str:
        """Plain-text rendering used for body_text, hashing and LLM prompts."""
        if self.kind == "list":
            # items keep their printed marker ("1.", "•"): re-numbering on
            # render would hide a list that skips or repeats a number
            return "\n".join(self.items)
        if self.kind == "table":
            return "\n".join(" | ".join(cell for cell in row) for row in self.rows)
        if self.kind == "figure":
            return f"[Figure] {self.text}".strip()
        return self.text

    def to_dict(self) -> dict:
        d = {"kind": self.kind, "page": self.page}
        if self.kind == "list":
            d.update(items=self.items, ordered=self.ordered)
        elif self.kind == "table":
            d.update(rows=self.rows)
        else:
            d.update(text=self.text)
        return d


@dataclass
class ParsedNode:
    key: str                     # unique within one parsed document, e.g. "2.1.1.1", "root", "4.2#2"
    number: Optional[str]        # section number as printed, None for the root
    title: str
    level: int                   # depth implied by the numbering ("2.1.1.1" -> 4); root = 0
    parent_key: Optional[str]
    order_index: int             # position in reading order
    page_start: int
    page_end: int
    blocks: list[Block] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    depth: int = 0               # actual depth in the reconstructed tree (can differ from level)
    refs: list[str] = field(default_factory=list)   # section numbers cited in the body ("see 4.2")
    heading_size: Optional[float] = None

    @property
    def body_text(self) -> str:
        return "\n\n".join(b.render() for b in self.blocks if b.render())

    @property
    def content_hash(self) -> str:
        return content_hash(self.title, self.body_text)

    @property
    def heading(self) -> str:
        return f"{self.number} {self.title}" if self.number else self.title

    def normalized_body(self) -> str:
        return normalize_text(self.body_text)


@dataclass
class ParseResult:
    title: str
    nodes: list[ParsedNode]
    warnings: list[str] = field(default_factory=list)
    page_methods: dict[int, str] = field(default_factory=dict)  # page -> "text_layer" | "ocr"
    stats: dict = field(default_factory=dict)

    def by_key(self) -> dict[str, ParsedNode]:
        return {n.key: n for n in self.nodes}

    def get(self, key: str) -> ParsedNode:
        return self.by_key()[key]
