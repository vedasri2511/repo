"""Layout extraction: turns each PDF page into an ordered list of items
(text lines, tables, figures) with position and font information.

Why characters and not pdfplumber words: in this manual the U+2011 hyphen is
drawn from a fallback font a fraction of a point off the baseline. Word
grouping by `top` then splits "CT‑200" into "CT", "‑", "200" or moves the
hyphen to a separate line, which made unchanged sections look modified between
v1 and v2. Clustering characters by vertical *overlap* fixes that.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

LIGATURES = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl"}
FALLBACK_FONT_HINTS = ("Serif",)  # glyphs substituted from another font; ignored for style


@dataclass
class Line:
    page: int
    top: float
    bottom: float
    x0: float
    x1: float
    text: str
    bold: Optional[bool]          # None when unknown (OCR)
    size: Optional[float]         # dominant font size, None for OCR
    source: str = "text_layer"    # or "ocr"
    kind: str = "line"


@dataclass
class TableItem:
    page: int
    top: float
    bottom: float
    rows: list[list[str]]
    kind: str = "table"


@dataclass
class FigureItem:
    page: int
    top: float
    bottom: float
    caption: str = ""
    kind: str = "figure"


@dataclass
class PageLayout:
    page: int
    height: float
    items: list = field(default_factory=list)
    method: str = "text_layer"
    total_chars: int = 0          # non-space characters in the text layer
    assigned_chars: int = 0       # of those, how many ended up in a line/table


def fix_glyphs(text: str) -> str:
    for src, dst in LIGATURES.items():
        text = text.replace(src, dst)
    return text


def _inside(ch: dict, bbox: tuple) -> bool:
    x0, top, x1, bottom = bbox
    cx = (ch["x0"] + ch["x1"]) / 2
    cy = (ch["top"] + ch["bottom"]) / 2
    return x0 - 1 <= cx <= x1 + 1 and top - 1 <= cy <= bottom + 1


def _contains(outer: tuple, inner: tuple) -> bool:
    return (outer[0] - 1 <= inner[0] and outer[1] - 1 <= inner[1]
            and outer[2] + 1 >= inner[2] and outer[3] + 1 >= inner[3])


def find_tables(page) -> list:
    """Real tables only: pdfplumber also reports small 'tables' built from the
    cell-background rectangles *inside* a real table; drop anything nested."""
    tables = page.find_tables()
    keep = []
    for t in sorted(tables, key=lambda t: -(t.bbox[2] - t.bbox[0]) * (t.bbox[3] - t.bbox[1])):
        if any(_contains(k.bbox, t.bbox) for k in keep):
            continue
        keep.append(t)
    return sorted(keep, key=lambda t: t.bbox[1])


def _clean_cell(cell: Optional[str]) -> str:
    if cell is None:
        return ""
    return re.sub(r"\s+", " ", fix_glyphs(cell)).strip()


def cluster_lines(chars: list[dict], page_no: int) -> list[Line]:
    """Group characters into visual lines by vertical overlap."""
    chars = sorted(chars, key=lambda c: (c["top"], c["x0"]))
    groups: list[dict] = []
    for ch in chars:
        h = max(ch["bottom"] - ch["top"], 1.0)
        placed = False
        for g in reversed(groups[-3:]):  # only recent lines can overlap
            overlap = min(g["bottom"], ch["bottom"]) - max(g["top"], ch["top"])
            if overlap >= 0.5 * h:
                g["chars"].append(ch)
                g["top"] = min(g["top"], ch["top"])
                g["bottom"] = max(g["bottom"], ch["bottom"])
                placed = True
                break
        if not placed:
            groups.append({"top": ch["top"], "bottom": ch["bottom"], "chars": [ch]})

    lines = []
    for g in groups:
        cs = sorted(g["chars"], key=lambda c: c["x0"])
        parts: list[str] = []
        prev = None
        for c in cs:
            if prev is not None and c["text"] != " " and parts and parts[-1] != " ":
                gap = c["x0"] - prev["x1"]
                if gap > 0.25 * c["size"]:
                    parts.append(" ")  # visual gap without an explicit space glyph
            parts.append(c["text"])
            prev = c
        text = fix_glyphs("".join(parts)).strip()
        if not text:
            continue
        styled = [c for c in cs if c["text"].strip()
                  and not any(h in c["fontname"] for h in FALLBACK_FONT_HINTS)] or \
                 [c for c in cs if c["text"].strip()]
        bold_share = sum("Bold" in c["fontname"] for c in styled) / len(styled)
        sizes: dict[float, int] = {}
        for c in styled:
            sizes[round(c["size"], 1)] = sizes.get(round(c["size"], 1), 0) + 1
        lines.append(Line(
            page=page_no, top=g["top"], bottom=g["bottom"],
            x0=min(c["x0"] for c in cs if c["text"].strip()),
            x1=max(c["x1"] for c in cs), text=text,
            bold=bold_share >= 0.9, size=max(sizes, key=sizes.get),
        ))
    return lines


def extract_page(page, page_no: int) -> PageLayout:
    layout = PageLayout(page=page_no, height=float(page.height))
    visible = [c for c in page.chars if c["text"].strip()]
    layout.total_chars = len(visible)

    table_items = []
    table_bboxes = []
    for t in find_tables(page):
        rows = [[_clean_cell(c) for c in row] for row in t.extract()]
        rows = [r for r in rows if any(r)]
        if not rows:
            continue
        table_bboxes.append(t.bbox)
        table_items.append(TableItem(page=page_no, top=t.bbox[1], bottom=t.bbox[3], rows=rows))

    free = [c for c in page.chars if not any(_inside(c, b) for b in table_bboxes)]
    lines = cluster_lines(free, page_no)

    # Coverage accounting: every visible glyph must land in exactly one line or
    # table cell. The structure step turns a mismatch into a document warning.
    def glyphs(s: str) -> int:
        return len(re.sub(r"\s", "", fix_glyphs(s)))

    layout.total_chars = glyphs("".join(c["text"] for c in visible))
    layout.assigned_chars = (sum(glyphs(l.text) for l in lines)
                             + sum(glyphs("".join(c for r in t.rows for c in r)) for t in table_items))

    figures = [FigureItem(page=page_no, top=im["top"], bottom=im["bottom"]) for im in page.images]

    layout.items = sorted([*lines, *table_items, *figures], key=lambda it: it.top)
    return layout
