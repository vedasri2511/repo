"""Relational model (SQLite via SQLAlchemy).

Three ideas carry the versioning design:

* **LogicalNode** – the identity of a section across versions ("the Error Codes
  section of chapter 4"). Its id is the node id the API exposes.
* **NodeRevision** – immutable content (title, body, blocks, content hash). A new
  revision is written only when a logical node's content actually changes, so an
  unchanged section in v2 points at the *same* revision row as in v1: nothing
  is duplicated, and old text can never be overwritten.
* **TreeEntry** – where a logical node sits in one document version (number,
  parent, order, pages, parser warnings) and which revision it shows there.

A version's tree is the set of its TreeEntries; selections pin
(logical node, version) pairs plus the revision/hash seen at pin time.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Document(Base):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(64), unique=True)
    title: Mapped[str] = mapped_column(String(500), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    versions: Mapped[list["DocumentVersion"]] = relationship(
        back_populates="document", order_by="DocumentVersion.version_number")


class DocumentVersion(Base):
    __tablename__ = "document_versions"
    __table_args__ = (UniqueConstraint("document_id", "version_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"))
    version_number: Mapped[int] = mapped_column(Integer)
    source_filename: Mapped[str] = mapped_column(String(300))
    file_sha256: Mapped[str] = mapped_column(String(64))
    title: Mapped[str] = mapped_column(String(500), default="")
    ingested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    parse_warnings: Mapped[list] = mapped_column(JSON, default=list)
    parse_stats: Mapped[dict] = mapped_column(JSON, default=dict)
    matching_report: Mapped[dict] = mapped_column(JSON, default=dict)
    document: Mapped[Document] = relationship(back_populates="versions")
    entries: Mapped[list["TreeEntry"]] = relationship(back_populates="version", order_by="TreeEntry.order_index")


class LogicalNode(Base):
    __tablename__ = "logical_nodes"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"))
    first_version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"))
    origin_key: Mapped[str] = mapped_column(String(64))  # section key when first seen, e.g. "4.2"
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class NodeRevision(Base):
    __tablename__ = "node_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    logical_node_id: Mapped[int] = mapped_column(ForeignKey("logical_nodes.id"), index=True)
    title: Mapped[str] = mapped_column(String(500))
    body_text: Mapped[str] = mapped_column(Text, default="")
    blocks: Mapped[list] = mapped_column(JSON, default=list)
    content_hash: Mapped[str] = mapped_column(String(64), index=True)
    created_in_version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"))
    previous_revision_id: Mapped[Optional[int]] = mapped_column(ForeignKey("node_revisions.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TreeEntry(Base):
    __tablename__ = "tree_entries"
    __table_args__ = (
        UniqueConstraint("document_version_id", "logical_node_id"),
        UniqueConstraint("document_version_id", "section_key"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    document_version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"), index=True)
    logical_node_id: Mapped[int] = mapped_column(ForeignKey("logical_nodes.id"), index=True)
    revision_id: Mapped[int] = mapped_column(ForeignKey("node_revisions.id"))
    parent_logical_node_id: Mapped[Optional[int]] = mapped_column(ForeignKey("logical_nodes.id"), nullable=True)
    section_key: Mapped[str] = mapped_column(String(64))
    section_number: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    level: Mapped[int] = mapped_column(Integer)
    depth: Mapped[int] = mapped_column(Integer)
    order_index: Mapped[int] = mapped_column(Integer)
    page_start: Mapped[int] = mapped_column(Integer)
    page_end: Mapped[int] = mapped_column(Integer)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    refs: Mapped[list] = mapped_column(JSON, default=list)
    # versus the previous version: added | unchanged | modified | moved
    change_status: Mapped[str] = mapped_column(String(16))
    match_rule: Mapped[str] = mapped_column(String(32))  # how the matcher linked it (or "new")
    version: Mapped[DocumentVersion] = relationship(back_populates="entries")
    revision: Mapped[NodeRevision] = relationship()


class Selection(Base):
    __tablename__ = "selections"
    __table_args__ = (UniqueConstraint("document_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("documents.id"))
    name: Mapped[str] = mapped_column(String(200))
    include_descendants: Mapped[bool] = mapped_column(Boolean, default=True)
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    items: Mapped[list["SelectionItem"]] = relationship(back_populates="selection", order_by="SelectionItem.position")


class SelectionItem(Base):
    __tablename__ = "selection_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    selection_id: Mapped[int] = mapped_column(ForeignKey("selections.id"), index=True)
    position: Mapped[int] = mapped_column(Integer)
    logical_node_id: Mapped[int] = mapped_column(ForeignKey("logical_nodes.id"))
    document_version_id: Mapped[int] = mapped_column(ForeignKey("document_versions.id"))
    revision_id: Mapped[int] = mapped_column(ForeignKey("node_revisions.id"))
    content_hash: Mapped[str] = mapped_column(String(64))
    selection: Mapped[Selection] = relationship(back_populates="items")
