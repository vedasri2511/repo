"""LLM test-case generation with structured-output validation.

Pipeline for one request:

  selection ──► pinned source text (exact revisions) ──► prompt
     ──► LLM ──► extract JSON ──► schema-validate each case (Pydantic)
     ──► semantic checks: cited sections must be in the prompt, source_quote
         must actually appear in a cited section (grounding)
     ──► ≥3 valid cases? accept (keep at most 5)
         else retry with a repair message listing the exact errors
     ──► after LLM_MAX_ATTEMPTS: store as FAILED with every raw attempt.

Policy decisions (defended in the approach doc):

* Partial acceptance per case: one malformed case out of five does not throw
  away four good ones, but an invalid case is never stored as a test case.
  Rejected cases are kept in the attempt log with reasons.
* Ungrounded output is treated as invalid: in a medical-device QA context a
  plausible test case built on a threshold the manual never states is worse
  than no test case.
* Failed generations are stored (status "failed") for audit and are never
  returned as test cases; the API answers 502 with the stored id.
* Same selection submitted twice: if an *accepted* generation exists for the
  same request key (selection + exact source revisions + prompt version +
  provider/model) it is returned (`reused: true`) without calling the LLM. LLM
  output is non-deterministic; silently piling up near-duplicate test sets
  for the same text muddies traceability and wastes quota. ``force=true``
  creates a new generation that records which one it supersedes. A request
  for identical input already in progress gets 409.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import time
from datetime import datetime, timedelta, timezone
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Selection
from app.parser.normalize import loose_text
from app.services import selection as sel_svc
from app.services import tree
from app.services.diff import normative_tokens
from app.services.llm import LLMClient, LLMError, get_client
from app.services.store import GenerationStore, get_store, new_id

PROMPT_VERSION = "tc-prompt-v1"
MIN_CASES, MAX_CASES = 3, 5
GROUNDING_MIN_COVERAGE = 0.85
PENDING_TIMEOUT = timedelta(minutes=5)

SYSTEM_PROMPT = """You are a senior QA engineer writing verification test cases for a regulated \
home blood-pressure monitor (CardioTrack CT-200).

Rules:
1. Use ONLY the requirement text provided by the user. Do not invent thresholds, timings, codes or \
behaviours that are not stated in it. If the text is ambiguous, write a test that exposes the ambiguity.
2. Each test case must be concrete enough for another engineer to execute: explicit steps and a \
measurable expected result (values, codes, timings exactly as written in the source).
3. Prefer boundary, negative and safety cases where the text gives limits.
4. Every test case must cite the section number(s) it verifies in "source_sections" (only numbers \
that appear in the provided text) and copy a short VERBATIM excerpt (10-200 characters) from one \
cited section into "source_quote".
5. Return between 3 and 5 test cases.
6. Respond with a single JSON object and nothing else, matching exactly this shape:
{
  "test_cases": [
    {
      "title": "short imperative title",
      "objective": "what requirement is verified",
      "test_type": "functional | boundary | negative | safety | error_handling",
      "priority": "high | medium | low",
      "preconditions": ["..."],
      "steps": ["step 1", "step 2"],
      "expected_result": "observable, measurable outcome",
      "source_sections": ["4.2"],
      "source_quote": "verbatim excerpt from the cited section"
    }
  ]
}"""


# ---------------------------------------------------------------- schema ---

class TestCaseIdea(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    title: str = Field(min_length=5, max_length=160)
    objective: str = Field(min_length=5, max_length=600)
    test_type: Literal["functional", "boundary", "negative", "safety", "error_handling"]
    priority: Literal["high", "medium", "low"]
    preconditions: list[str] = Field(default_factory=list, max_length=10)
    steps: list[str] = Field(min_length=1, max_length=15)
    expected_result: str = Field(min_length=10, max_length=800)
    source_sections: list[str] = Field(min_length=1, max_length=6)
    source_quote: str = Field(min_length=10, max_length=400)

    @field_validator("test_type", "priority", mode="before")
    @classmethod
    def _lower(cls, v):
        return v.strip().lower().replace("-", "_").replace(" ", "_") if isinstance(v, str) else v

    @field_validator("steps", "preconditions")
    @classmethod
    def _no_blank(cls, v: list[str]) -> list[str]:
        v = [s.strip() for s in v if isinstance(s, str)]
        if any(not s for s in v):
            raise ValueError("contains an empty string")
        return v

    @field_validator("source_sections", mode="before")
    @classmethod
    def _sections(cls, v):
        if isinstance(v, str):
            v = [v]
        return [str(s).strip().removeprefix("Section ").removeprefix("§").rstrip(".") for s in v]


# --------------------------------------------------------------- parsing ---

def extract_json(text: str) -> dict:
    """Best-effort extraction of one JSON object from an LLM reply."""
    if not text or not text.strip():
        raise ValueError("empty response")
    s = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", s, re.S)
    if fence:
        s = fence.group(1).strip()
    try:
        data = json.loads(s)
    except json.JSONDecodeError:
        start = min([i for i in (s.find("{"), s.find("[")) if i >= 0], default=-1)
        end = max(s.rfind("}"), s.rfind("]"))
        if start < 0:
            raise ValueError("no JSON object found in response")
        if end <= start:
            raise ValueError("invalid JSON: truncated, no closing bracket (output cut off?)")
        try:
            data = json.loads(s[start:end + 1])
        except json.JSONDecodeError as e:
            raise ValueError(f"invalid JSON: {e.msg} at char {e.pos}") from e
    if isinstance(data, list):
        data = {"test_cases": data}
    if not isinstance(data, dict):
        raise ValueError("top-level JSON is not an object")
    if "test_cases" not in data:
        # tolerate one level of wrapping, e.g. {"result": {"test_cases": [...]}}
        inner = [v for v in data.values() if isinstance(v, dict) and "test_cases" in v]
        if inner:
            data = inner[0]
        else:
            raise ValueError(f"missing 'test_cases' key (got keys {sorted(data)[:6]})")
    if not isinstance(data["test_cases"], list):
        raise ValueError("'test_cases' is not a list")
    return data


def grounded(quote: str, source: str) -> bool:
    q, src = loose_text(quote), loose_text(source)
    if not q:
        return False
    if q in src:
        return True
    m = difflib.SequenceMatcher(None, src, q, autojunk=False).find_longest_match(0, len(src), 0, len(q))
    return m.size / len(q) >= GROUNDING_MIN_COVERAGE


def _values(text: str) -> set[str]:
    """Numbers/units/codes in a text (comparators and modal words excluded)."""
    return {t for t in normative_tokens(text) if not t.startswith(("cmp:", "word:"))}


def validate_cases(raw_cases: list, sources: list[dict]) -> tuple[list[dict], list[dict]]:
    """Returns (valid cases, rejected cases with reasons)."""
    text_by_section: dict[str, str] = {}
    nodes_by_section: dict[str, int] = {}
    for s in sources:
        if s["section_number"]:
            text_by_section[s["section_number"]] = f"{s['title']}\n{s['body_text']}"
            nodes_by_section[s["section_number"]] = s["node_id"]
    valid, rejected, titles = [], [], set()
    for i, raw in enumerate(raw_cases):
        try:
            case = TestCaseIdea.model_validate(raw)
        except ValidationError as e:
            errs = [f"{'.'.join(str(p) for p in err['loc'])}: {err['msg']}" for err in e.errors()]
            rejected.append({"index": i, "reasons": errs, "raw": raw})
            continue
        reasons = []
        unknown = [s for s in case.source_sections if s not in text_by_section]
        if unknown:
            reasons.append(f"source_sections {unknown} are not in the provided text "
                           f"(allowed: {sorted(text_by_section)})")
        cited = [text_by_section[s] for s in case.source_sections if s in text_by_section]
        if cited and not any(grounded(case.source_quote, t) for t in cited):
            reasons.append("source_quote does not appear verbatim in any cited section")
        elif cited:
            # fuzzy grounding tolerates small differences, but never in a number,
            # unit, code or comparator: "within 2 seconds" vs "within 1.5 seconds"
            quote_vals = _values(case.source_quote)
            source_vals = _values(" ".join(cited))
            altered = sorted(v for v in quote_vals if v not in source_vals)
            if altered:
                reasons.append(f"source_quote contains values not in the cited text: {altered}")
        if case.title.lower() in titles:
            reasons.append("duplicate title")
        if reasons:
            rejected.append({"index": i, "reasons": reasons, "raw": raw})
            continue
        titles.add(case.title.lower())
        d = case.model_dump()
        d["source_node_ids"] = [nodes_by_section[s] for s in case.source_sections]
        # Values in steps/expected result that the cited text does not state.
        # Kept (a boundary test may legitimately use 300 mmHg for a 299 limit)
        # but made visible to the reviewer.
        source_vals = _values(" ".join(cited))
        d["values_not_in_source"] = sorted(
            v for v in _values(" ".join([case.expected_result, *case.steps])) if v not in source_vals)
        valid.append(d)
    return valid, rejected


# ---------------------------------------------------------------- prompt ---

def build_user_prompt(selection_name: str, sources: list[dict]) -> str:
    parts = [f"Selection: {selection_name}\n",
             "Requirement text (CT-200 manual, exact version pinned by the selection):\n"]
    for s in sources:
        num = s["section_number"] or "0"
        body = s["body_text"].strip() or "(heading only, no body text)"
        parts.append(f"### SECTION {num} — {s['title']}\n{body}\n")
    parts.append("### END OF REQUIREMENT TEXT")
    parts.append(f"\nWrite {MIN_CASES}-{MAX_CASES} test cases as specified. JSON only.")
    return "\n".join(parts)


def repair_prompt(errors: list[str], previous: str = "") -> str:
    listed = "\n".join(f"- {e}" for e in errors[:20])
    prev = f"\n\nYour previous reply (truncated):\n{previous[:3000]}" if previous else ""
    return ("Your previous reply could not be accepted:\n" + listed + prev +
            f"\n\nReturn the complete JSON object again with {MIN_CASES}-{MAX_CASES} valid test cases. "
            "Cite only section numbers that appear in the requirement text and copy source_quote "
            "verbatim from a cited section. JSON only, no prose, no code fences.")


# --------------------------------------------------------------- service ---

class GenerationFailed(Exception):
    def __init__(self, gen_id: str, message: str):
        super().__init__(message)
        self.gen_id = gen_id


class GenerationInProgress(Exception):
    pass


def request_key(selection_id: int, sources: list[dict], provider: str, model: str) -> str:
    payload = {
        "selection_id": selection_id,
        "sources": sorted((s["node_id"], s["revision_id"], s["content_hash"]) for s in sources),
        "prompt_version": PROMPT_VERSION, "provider": provider, "model": model,
    }
    return hashlib.sha256(json.dumps(payload).encode()).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def generate(session: Session, selection_id: int, force: bool = False,
             client: Optional[LLMClient] = None, store: Optional[GenerationStore] = None) -> tuple[dict, bool]:
    """Returns (generation document, reused)."""
    store = store or get_store()
    settings = get_settings()
    sel: Selection = sel_svc.get_selection(session, selection_id)
    sources = sel_svc.resolve(session, sel)
    llm = get_client(client)
    key = request_key(sel.id, sources, llm.provider, llm.model)

    previous = store.find(request_key=key)
    accepted = [g for g in previous if g["status"].startswith("accepted")]
    if accepted and not force:
        return accepted[-1], True
    pending = [g for g in previous if g["status"] == "pending"
               and datetime.fromisoformat(g["created_at"]) > datetime.now(timezone.utc) - PENDING_TIMEOUT]
    if pending:
        raise GenerationInProgress(f"generation {pending[-1]['_id']} for identical input is in progress")

    doc_slug = tree.version_by_id(session, sel.items[0].document_version_id).document.slug
    gen_id = new_id()
    store.insert({
        "_id": gen_id, "status": "pending", "created_at": _now(), "completed_at": None,
        "selection_id": sel.id, "selection_name": sel.name, "document": doc_slug,
        "request_key": key, "prompt_version": PROMPT_VERSION,
        "provider": llm.provider, "model": llm.model,
        "supersedes": accepted[-1]["_id"] if accepted else None,
        "sources": [{k: s[k] for k in ("node_id", "section_number", "title", "version", "document_version_id",
                                       "revision_id", "content_hash", "role")} | {"text": s["body_text"]}
                    for s in sources],
        "test_cases": [], "attempts": [], "warnings": [], "error": None,
    })

    user = build_user_prompt(sel.name, sources)
    attempts, last_errors = [], []
    messages_user = user
    for attempt_no in range(1, settings.llm_max_attempts + 1):
        rec: dict = {"attempt": attempt_no, "at": _now()}
        try:
            resp = llm.complete(SYSTEM_PROMPT, messages_user)
        except LLMError as e:
            rec.update(error=str(e), retryable=e.retryable)
            attempts.append(rec)
            last_errors = [str(e)]
            if not e.retryable:
                break
            time.sleep(min(2 ** (attempt_no - 1), 8) if llm.provider != "mock" else 0)
            continue
        rec.update(raw_response=resp.text[:20000], latency_ms=resp.latency_ms, usage=resp.usage)
        try:
            data = extract_json(resp.text)
        except ValueError as e:
            rec["parse_error"] = str(e)
            attempts.append(rec)
            last_errors = [f"response was not valid JSON: {e}"]
            messages_user = user + "\n\n" + repair_prompt(last_errors, resp.text)
            continue
        valid, rejected = validate_cases(data["test_cases"], sources)
        rec.update(valid_cases=len(valid), rejected_cases=rejected)
        attempts.append(rec)
        if len(valid) >= MIN_CASES:
            warnings = []
            if len(valid) > MAX_CASES:
                warnings.append(f"model returned {len(valid)} valid cases; kept the first {MAX_CASES}")
                valid = valid[:MAX_CASES]
            if rejected:
                warnings.append(f"{len(rejected)} case(s) rejected by validation; see attempts")
            status = "accepted_with_warnings" if warnings else "accepted"
            if attempt_no > 1:
                warnings.append(f"accepted on attempt {attempt_no}")
            for n, c in enumerate(valid, start=1):
                c["case_id"] = f"TC-{gen_id[:8]}-{n}"
            store.update(gen_id, {"status": status, "test_cases": valid, "attempts": attempts,
                                  "warnings": warnings, "completed_at": _now()})
            return store.get(gen_id), False
        last_errors = [f"only {len(valid)} valid test case(s); need at least {MIN_CASES}"] + \
                      [f"case {r['index']}: {'; '.join(r['reasons'])}" for r in rejected]
        messages_user = user + "\n\n" + repair_prompt(last_errors, resp.text)

    message = f"no valid output after {len(attempts)} attempt(s): " + "; ".join(last_errors[:3])
    store.update(gen_id, {"status": "failed", "attempts": attempts, "error": message, "completed_at": _now()})
    raise GenerationFailed(gen_id, message)
