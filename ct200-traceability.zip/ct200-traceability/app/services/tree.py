"""Read-side helpers over the versioned tree."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Document, DocumentVersion, LogicalNode, NodeRevision, TreeEntry
from app.parser.normalize import loose_text
from app.services.diff import classify


class NotFound(Exception):
    pass


def get_document(session: Session, slug: str) -> Document:
    doc = session.scalar(select(Document).where(Document.slug == slug))
    if doc is None:
        raise NotFound(f"document '{slug}' not found")
    return doc


def resolve_version(session: Session, document_id: int, version_number: int | None) -> DocumentVersion:
    q = select(DocumentVersion).where(DocumentVersion.document_id == document_id)
    if version_number is None:
        q = q.order_by(DocumentVersion.version_number.desc()).limit(1)
    else:
        q = q.where(DocumentVersion.version_number == version_number)
    v = session.scalar(q)
    if v is None:
        raise NotFound(f"version {version_number or 'latest'} not found")
    return v


def version_by_id(session: Session, version_id: int) -> DocumentVersion:
    return session.get(DocumentVersion, version_id)


def entry(session: Session, version_id: int, logical_id: int) -> TreeEntry | None:
    return session.scalar(select(TreeEntry).where(TreeEntry.document_version_id == version_id,
                                                  TreeEntry.logical_node_id == logical_id))


def logical_node(session: Session, logical_id: int) -> LogicalNode:
    ln = session.get(LogicalNode, logical_id)
    if ln is None:
        raise NotFound(f"node {logical_id} not found")
    return ln


def entries(session: Session, version_id: int) -> list[TreeEntry]:
    return list(session.scalars(select(TreeEntry).where(TreeEntry.document_version_id == version_id)
                                .order_by(TreeEntry.order_index)))


def children(session: Session, version_id: int, logical_id: int | None) -> list[TreeEntry]:
    return list(session.scalars(
        select(TreeEntry).where(TreeEntry.document_version_id == version_id,
                                TreeEntry.parent_logical_node_id == logical_id)
        .order_by(TreeEntry.order_index)))


def root_entry(session: Session, version_id: int) -> TreeEntry:
    return session.scalar(select(TreeEntry).where(TreeEntry.document_version_id == version_id,
                                                  TreeEntry.section_key == "root"))


def subtree(session: Session, version_id: int, logical_id: int) -> list[TreeEntry]:
    """The node and all its descendants in reading order."""
    all_entries = entries(session, version_id)
    kids: dict[int | None, list[TreeEntry]] = {}
    for e in all_entries:
        kids.setdefault(e.parent_logical_node_id, []).append(e)
    start = next((e for e in all_entries if e.logical_node_id == logical_id), None)
    if start is None:
        return []
    out, stack = [], [start]
    while stack:
        e = stack.pop()
        out.append(e)
        stack.extend(reversed(kids.get(e.logical_node_id, [])))
    return sorted(out, key=lambda e: e.order_index)


def history(session: Session, logical_id: int) -> list[tuple[DocumentVersion, TreeEntry]]:
    rows = session.execute(
        select(DocumentVersion, TreeEntry).join(TreeEntry, TreeEntry.document_version_id == DocumentVersion.id)
        .where(TreeEntry.logical_node_id == logical_id).order_by(DocumentVersion.version_number)).all()
    return [(v, e) for v, e in rows]


def search(session: Session, version_id: int, q: str, field: str = "both", limit: int = 50) -> list[dict]:
    needle = loose_text(q)
    hits = []
    for e in entries(session, version_id):
        rev = e.revision
        heading = f"{e.section_number or ''} {rev.title}".strip()
        in_heading = needle in loose_text(heading)
        body = loose_text(rev.body_text)
        in_text = needle in body
        if (field == "heading" and in_heading) or (field == "text" and in_text) or \
                (field == "both" and (in_heading or in_text)):
            snippet = ""
            if in_text:
                i = body.find(needle)
                snippet = ("…" if i > 60 else "") + body[max(0, i - 60): i + len(needle) + 60] + "…"
            hits.append({"node_id": e.logical_node_id, "section_number": e.section_number,
                         "title": rev.title, "matched_in": "heading" if in_heading else "text",
                         "snippet": snippet})
            if len(hits) >= limit:
                break
    return hits


def change_report(session: Session, logical_id: int) -> dict:
    """Has this node changed across versions? Diff summary per transition."""
    ln = logical_node(session, logical_id)
    hist = history(session, logical_id)
    all_versions = list(session.scalars(select(DocumentVersion)
                                        .where(DocumentVersion.document_id == ln.document_id)
                                        .order_by(DocumentVersion.version_number)))
    present = {v.id: e for v, e in hist}
    timeline, transitions = [], []
    prev_entry, prev_version = None, None
    for v in all_versions:
        e = present.get(v.id)
        timeline.append({
            "version": v.version_number, "present": e is not None,
            "section_number": e.section_number if e else None,
            "revision_id": e.revision_id if e else None,
            "content_hash": e.revision.content_hash if e else None,
            "change_status": e.change_status if e else "absent",
        })
        if prev_version is not None and (prev_entry is not None or e is not None):
            if prev_entry is None:
                t = {"changed": True, "severity": "added", "summary": "node added in this version"}
            elif e is None:
                t = {"changed": True, "severity": "removed", "summary": "node removed in this version"}
            else:
                a, b = prev_entry.revision, e.revision
                t = classify(a.title, a.body_text, b.title, b.body_text)
                if prev_entry.section_number != e.section_number:
                    t["renumbered"] = {"from": prev_entry.section_number, "to": e.section_number}
                    t["changed"] = True
            t.update({"from_version": prev_version.version_number, "to_version": v.version_number})
            transitions.append(t)
        prev_entry, prev_version = e, v
    return {
        "node_id": logical_id,
        "changed_in_any_version": any(t.get("changed") for t in transitions),
        "changed_in_latest": bool(transitions and transitions[-1].get("changed")),
        "timeline": timeline,
        "transitions": transitions,
    }


def revision(session: Session, revision_id: int) -> NodeRevision:
    return session.get(NodeRevision, revision_id)
