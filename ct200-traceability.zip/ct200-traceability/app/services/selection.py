"""Selections: named, version-pinned sets of nodes.

Each item pins (logical node, document version) and records the revision id and
content hash it saw. Revisions are immutable and a version's tree is never
rewritten, so a selection resolves to exactly the same text forever, no matter
how many versions are ingested later.

Policy for creating the same selection twice:
  * same name + same pinned items  -> returns the existing selection (idempotent);
  * same name + different items    -> 409 conflict (names identify selections);
  * different name + same items    -> allowed, a separate selection (names are
    user labels and two teams may legitimately select the same text).
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Selection, SelectionItem
from app.services import tree


class Conflict(Exception):
    pass


class Invalid(Exception):
    pass


@dataclass
class ItemRequest:
    node_id: int
    version: int | None = None


def fingerprint(pairs: list[tuple[int, int]], include_descendants: bool) -> str:
    payload = json.dumps({"items": sorted(pairs), "desc": include_descendants})
    return hashlib.sha256(payload.encode()).hexdigest()


def create_selection(session: Session, slug: str, name: str, items: list[ItemRequest],
                     default_version: int | None, include_descendants: bool) -> tuple[Selection, bool]:
    doc = tree.get_document(session, slug)
    if not items:
        raise Invalid("a selection needs at least one node")
    resolved, errors, seen = [], [], set()
    for it in items:
        version = tree.resolve_version(session, doc.id, it.version if it.version is not None else default_version)
        e = tree.entry(session, version.id, it.node_id)
        if e is None:
            errors.append(f"node {it.node_id} does not exist in version {version.version_number}")
            continue
        if (it.node_id, version.id) in seen:
            continue
        seen.add((it.node_id, version.id))
        resolved.append((e, version))
    if errors:
        raise Invalid("; ".join(errors))

    fp = fingerprint([(e.logical_node_id, v.id) for e, v in resolved], include_descendants)
    existing = session.scalar(select(Selection).where(Selection.document_id == doc.id, Selection.name == name))
    if existing is not None:
        if existing.fingerprint == fp:
            return existing, False
        raise Conflict(f"a selection named '{name}' already exists (id {existing.id}) pinned to different "
                       f"node versions; requests without an explicit version pin to the latest version, "
                       f"which may have changed since. Use another name or pin the same version.")

    sel = Selection(document_id=doc.id, name=name, include_descendants=include_descendants, fingerprint=fp)
    session.add(sel)
    session.flush()
    for pos, (e, v) in enumerate(resolved):
        session.add(SelectionItem(selection_id=sel.id, position=pos, logical_node_id=e.logical_node_id,
                                  document_version_id=v.id, revision_id=e.revision_id,
                                  content_hash=e.revision.content_hash))
    session.commit()
    session.refresh(sel)
    return sel, True


def get_selection(session: Session, selection_id: int) -> Selection:
    sel = session.get(Selection, selection_id)
    if sel is None:
        raise tree.NotFound(f"selection {selection_id} not found")
    return sel


def resolve(session: Session, sel: Selection) -> list[dict]:
    """Exact pinned text of the selection, including descendants if requested.

    Returns one entry per node that contributes text, in document order per item.
    """
    out, seen = [], set()
    for item in sel.items:
        version = tree.version_by_id(session, item.document_version_id)
        entries = (tree.subtree(session, version.id, item.logical_node_id) if sel.include_descendants
                   else [tree.entry(session, version.id, item.logical_node_id)])
        for e in entries:
            if (e.logical_node_id, version.id) in seen:
                continue
            seen.add((e.logical_node_id, version.id))
            rev = e.revision
            if e.logical_node_id == item.logical_node_id and rev.id != item.revision_id:
                # cannot happen unless the database was edited by hand
                raise RuntimeError(f"selection {sel.id}: pinned revision {item.revision_id} "
                                   f"no longer in version {version.version_number}")
            out.append({
                "node_id": e.logical_node_id,
                "version": version.version_number,
                "document_version_id": version.id,
                "section_number": e.section_number,
                "title": rev.title,
                "revision_id": rev.id,
                "content_hash": rev.content_hash,
                "body_text": rev.body_text,
                "role": "selected" if e.logical_node_id == item.logical_node_id else "descendant",
            })
    return out


def selections_for_node(session: Session, logical_id: int) -> list[Selection]:
    ids = session.scalars(select(SelectionItem.selection_id).where(SelectionItem.logical_node_id == logical_id))
    return [session.get(Selection, i) for i in set(ids)]
