"""Version matcher: decides which nodes of a newly parsed version are the *same
logical node* as a node of the previous version.

Rules, applied in this order, each only to nodes still unmatched:

  R1 number+title   same section number and same normalized title.
  R2 content-hash   identical content hash, unique on both sides.
                    Catches renumbered/moved sections whose text is unchanged.
  R3 title+parent   same normalized title and the parents are already matched
                    to each other; unique candidate only. Catches a renumbered
                    section that was also edited.
  R4 number+fuzzy   same section number and title similarity >= 0.75.
                    Catches small title edits ("Cuff Spec" -> "Cuff Specifications").

Anything left is "added" (new) or "removed" (old). Ambiguous candidates are
never guessed: the node becomes new and the ambiguity is reported.

Why number-first rather than hash-first: the nodes we most need to link are the
ones whose text changed, and their hash is by definition different. Why not
title-only: this manual repeats titles ("Error Codes" in 4.2 and 7.1).

Where it breaks (also in the approach doc):
  * renumbered AND retitled AND edited in the same release -> delete + add
    (traceability lost, but loudly: old generations report "source removed");
  * a section *split* into two, or two *merged*, is modelled as modified + added
    or modified + removed, never as a split/merge;
  * two sections that swap numbers but keep their titles are matched by R1 only
    if the titles also swap, otherwise R3/R4 can mis-link them.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Optional

from app.parser.model import ParsedNode, ParseResult
from app.parser.normalize import loose_text

FUZZY_TITLE_MIN = 0.75
LOW_CONFIDENCE_SIMILARITY = 0.5


@dataclass
class PrevNode:
    logical_id: int
    key: str
    number: Optional[str]
    title: str
    content_hash: str
    parent_logical_id: Optional[int]
    body: str = ""


@dataclass
class Match:
    new_key: str
    logical_id: Optional[int]           # None -> new logical node
    rule: str                           # "R1_number_title" | ... | "new"
    status: str                         # added | unchanged | modified | moved
    previous: Optional[PrevNode] = None
    notes: list[str] = field(default_factory=list)


def _t(s: str) -> str:
    return loose_text(s)


def match_versions(prev: list[PrevNode], new: ParseResult) -> tuple[dict[str, Match], dict]:
    new_nodes = new.nodes
    matched_new: dict[str, PrevNode] = {}
    rule_of: dict[str, str] = {}
    used_prev: set[int] = set()
    ambiguous: list[str] = []

    def link(n: ParsedNode, p: PrevNode, rule: str):
        matched_new[n.key] = p
        rule_of[n.key] = rule
        used_prev.add(p.logical_id)

    def free_prev():
        return [p for p in prev if p.logical_id not in used_prev]

    # R1 number + title
    for n in new_nodes:
        cands = [p for p in free_prev() if p.number == n.number and _t(p.title) == _t(n.title)]
        if n.key == "root":
            cands = [p for p in free_prev() if p.key == "root"]
        if len(cands) == 1:
            link(n, cands[0], "R1_number_title")
        elif len(cands) > 1:
            ambiguous.append(f"{n.key}: {len(cands)} previous nodes share number and title")

    # R2 identical content, unique on both sides
    for n in new_nodes:
        if n.key in matched_new:
            continue
        cands = [p for p in free_prev() if p.content_hash == n.content_hash]
        same_new = [m for m in new_nodes if m.key not in matched_new and m.content_hash == n.content_hash]
        if len(cands) == 1 and len(same_new) == 1:
            link(n, cands[0], "R2_content_hash")
        elif len(cands) > 1:
            ambiguous.append(f"{n.key}: identical content in {len(cands)} previous nodes")

    # R3 same title under already-matched parents (parents first: reading order)
    for n in new_nodes:
        if n.key in matched_new or n.parent_key is None:
            continue
        parent_prev = matched_new.get(n.parent_key)
        if parent_prev is None:
            continue
        cands = [p for p in free_prev()
                 if _t(p.title) == _t(n.title) and p.parent_logical_id == parent_prev.logical_id]
        if len(cands) == 1:
            link(n, cands[0], "R3_title_parent")
        elif len(cands) > 1:
            ambiguous.append(f"{n.key}: {len(cands)} same-titled siblings under {n.parent_key}")

    # R4 same number, similar title
    for n in new_nodes:
        if n.key in matched_new or n.number is None:
            continue
        scored = [(difflib.SequenceMatcher(a=_t(p.title), b=_t(n.title)).ratio(), p)
                  for p in free_prev() if p.number == n.number]
        good = [(s, p) for s, p in scored if s >= FUZZY_TITLE_MIN]
        if len(good) == 1:
            link(n, good[0][1], "R4_number_fuzzy_title")

    # statuses
    prev_by_id = {p.logical_id: p for p in prev}
    results: dict[str, Match] = {}
    for n in new_nodes:
        p = matched_new.get(n.key)
        if p is None:
            results[n.key] = Match(n.key, None, "new", "added")
            continue
        notes = []
        parent_prev = matched_new.get(n.parent_key) if n.parent_key else None
        same_place = (p.number == n.number and
                      (parent_prev.logical_id if parent_prev else None) == p.parent_logical_id)
        if p.number != n.number:
            notes.append(f"renumbered {p.number} -> {n.number}")
        if _t(p.title) != _t(n.title):
            notes.append(f"retitled {p.title!r} -> {n.title!r}")
        if p.content_hash != n.content_hash and (p.body or n.body_text):
            sim = difflib.SequenceMatcher(None, _t(p.body), _t(n.body_text), autojunk=False).ratio()
            if sim < LOW_CONFIDENCE_SIMILARITY:
                notes.append(f"low confidence: only {sim:.0%} of the body text is shared with the "
                             f"node it was matched to ({rule_of[n.key]}); check this identity by hand")
        if p.content_hash != n.content_hash:
            status = "modified"
        elif not same_place:
            status = "moved"
        else:
            status = "unchanged"
        results[n.key] = Match(n.key, p.logical_id, rule_of[n.key], status, previous=p, notes=notes)

    removed = [prev_by_id[i] for i in prev_by_id if i not in used_prev]
    report = {
        "counts": {s: sum(1 for m in results.values() if m.status == s)
                   for s in ("unchanged", "modified", "moved", "added")} | {"removed": len(removed)},
        "rules": {r: sum(1 for m in results.values() if m.rule == r)
                  for r in sorted({m.rule for m in results.values()})},
        "added": [k for k, m in results.items() if m.status == "added"],
        "modified": [k for k, m in results.items() if m.status == "modified"],
        "moved": [k for k, m in results.items() if m.status == "moved"],
        "removed": [{"logical_node_id": p.logical_id, "key": p.key, "title": p.title} for p in removed],
        "notes": {k: m.notes for k, m in results.items() if m.notes},
        "ambiguous": ambiguous,
        "low_confidence": [k for k, m in results.items() if any(x.startswith("low confidence") for x in m.notes)],
    }
    return results, report
