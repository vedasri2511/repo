"""Staleness / impact detection, computed at retrieval time.

A generation stores, for every node whose text went into the prompt, the
(node, version, revision, content hash) it was generated from. When someone
retrieves it we compare each source with the same logical node in the
*latest* version of the document:

  current        – identical content hash
  possibly_stale – hash differs but the change is editorial/cosmetic
                   (no number, unit, code, comparator or modal word changed)
  stale          – a normative token changed, or the node was removed

The generation's status is the worst of its sources. Per test case we also
report which of its own cited sources changed and whether its text mentions a
normative value that no longer appears in the current text (e.g. a test
expecting "within 2 seconds" after E3 changed to 1.5 s): that is the strongest
evidence a case is now wrong.

Deliberate limits:
  * Any hash change is surfaced; severity only orders the review. We never call
    a changed requirement "current", because the classifier cannot understand
    meaning (an added "not" is caught, "adults" -> "children" is not).
  * Cross-references are reported as *related* changes only (7.1 says "see
    Section 4.2"; if 4.2 changes, 7.1's test cases may be affected, but the 7.1
    text itself did not change).
  * Staleness is relative to the latest version only, not to an arbitrary one.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.services import tree
from app.services.diff import classify, normative_tokens

RANK = {"current": 0, "possibly_stale": 1, "stale": 2}


def _source_status(session: Session, latest_version_id: int, src: dict) -> dict:
    e = tree.entry(session, latest_version_id, src["node_id"])
    base = {"node_id": src["node_id"], "section_number": src["section_number"], "title": src["title"],
            "generated_from_version": src["version"], "generated_from_hash": src["content_hash"]}
    if e is None:
        return base | {"status": "stale", "reason": "node no longer exists in the latest version",
                       "current_hash": None, "severity": "removed", "removed_values": [], "diff": None}
    cur = e.revision
    if cur.content_hash == src["content_hash"]:
        renumber = (f"renumbered {src['section_number']} -> {e.section_number}"
                    if e.section_number != src["section_number"] else None)
        return base | {"_current_text": cur.title + "\n" + cur.body_text,
                       "status": "current", "current_hash": cur.content_hash, "severity": "none",
                       "reason": renumber or "text unchanged", "removed_values": [], "diff": None}
    d = classify(src["title"], src["text"], cur.title, cur.body_text)
    status = "stale" if d["severity"] == "substantive" else "possibly_stale"
    return base | {
        "_current_text": cur.title + "\n" + cur.body_text,
        "status": status, "current_hash": cur.content_hash, "severity": d["severity"],
        "current_section_number": e.section_number,
        "reason": d["summary"], "removed_values": d.get("normative_removed", []),
        "added_values": d.get("normative_added", []),
        "diff": d["ops"],
    }


def _related(session: Session, latest_version_id: int, sources: list[dict], source_ids: set[int]) -> list[dict]:
    """Sections cross-referenced by a source (in its pinned version) that changed since."""
    out = []
    for src in sources:
        pinned = tree.entry(session, src["document_version_id"], src["node_id"])
        for ref in (pinned.refs if pinned else []):
            ref_entry = next((x for x in tree.entries(session, src["document_version_id"])
                              if x.section_number == ref), None)
            if ref_entry is None or ref_entry.logical_node_id in source_ids:
                continue
            now = tree.entry(session, latest_version_id, ref_entry.logical_node_id)
            if now is None or now.revision_id != ref_entry.revision_id:
                out.append({"from_section": src["section_number"], "referenced_section": ref,
                            "node_id": ref_entry.logical_node_id,
                            "change": "removed" if now is None else "modified"})
    return out


def evaluate(session: Session, gen: dict) -> dict:
    doc = tree.get_document(session, gen["document"])
    latest = tree.resolve_version(session, doc.id, None)
    sources = [_source_status(session, latest.id, s) for s in gen["sources"]]
    by_node = {s["node_id"]: s for s in sources}
    overall = max((s["status"] for s in sources), key=RANK.get, default="current")

    cases = []
    for c in gen.get("test_cases", []):
        cited = [by_node[n] for n in c.get("source_node_ids", []) if n in by_node]
        status = max((s["status"] for s in cited), key=RANK.get, default="current")
        case_text = " ".join([c.get("expected_result", ""), c.get("source_quote", ""), *c.get("steps", [])])
        case_values = normative_tokens(case_text)
        still_stated = normative_tokens(" ".join(s.get("_current_text", "") for s in cited))
        contradicted = sorted({v for s in cited for v in s.get("removed_values", [])
                               if not v.startswith(("cmp:", "word:")) and case_values.get(v)
                               and not still_stated.get(v)})
        cases.append({
            "case_id": c.get("case_id"), "title": c.get("title"), "status": status,
            "changed_sources": [s["section_number"] for s in cited if s["status"] != "current"],
            "mentions_values_no_longer_in_source": contradicted,
        })

    related = _related(session, latest.id, gen["sources"], set(by_node))
    for src in sources:
        src.pop("_current_text", None)
    return {
        "status": overall,
        "evaluated_against_version": latest.version_number,
        "generated_from_versions": sorted({s["version"] for s in gen["sources"]}),
        "summary": _summary(overall, sources, cases, related),
        "sources": sources,
        "test_cases": cases,
        "related_changes": related,
    }


def _summary(overall: str, sources: list[dict], cases: list[dict], related: list[dict]) -> str:
    if overall == "current":
        msg = "All source text is unchanged in the latest version."
    else:
        changed = [f"{s['section_number']} ({s['severity']})" for s in sources if s["status"] != "current"]
        hit = [c["case_id"] for c in cases if c["mentions_values_no_longer_in_source"]]
        msg = f"Source text changed: {', '.join(changed)}."
        if hit:
            msg += f" Test cases that assert values no longer in the manual: {', '.join(hit)}."
    if related:
        msg += " Referenced sections changed: " + ", ".join(
            f"{r['referenced_section']} (cited by {r['from_section']})" for r in related) + "."
    return msg
