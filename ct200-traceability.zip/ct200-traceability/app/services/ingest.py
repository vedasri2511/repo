"""Ingestion: parse a PDF and persist it as a new version of a document."""
from __future__ import annotations

import hashlib
import tempfile
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Document, DocumentVersion, LogicalNode, NodeRevision, TreeEntry
from app.parser import parse_pdf
from app.parser.model import ParseResult
from app.services.matching import PrevNode, match_versions


class IngestResult:
    def __init__(self, version: DocumentVersion, created: bool):
        self.version = version
        self.created = created


def get_or_create_document(session: Session, slug: str) -> Document:
    doc = session.scalar(select(Document).where(Document.slug == slug))
    if doc is None:
        doc = Document(slug=slug)
        session.add(doc)
        session.flush()
    return doc


def latest_version(session: Session, document_id: int) -> DocumentVersion | None:
    return session.scalar(
        select(DocumentVersion).where(DocumentVersion.document_id == document_id)
        .order_by(DocumentVersion.version_number.desc()).limit(1))


def _previous_nodes(session: Session, version: DocumentVersion) -> list[PrevNode]:
    rows = session.execute(
        select(TreeEntry, NodeRevision).join(NodeRevision, TreeEntry.revision_id == NodeRevision.id)
        .where(TreeEntry.document_version_id == version.id)
    ).all()
    return [PrevNode(logical_id=e.logical_node_id, key=e.section_key, number=e.section_number,
                     title=r.title, content_hash=r.content_hash,
                     parent_logical_id=e.parent_logical_node_id, body=r.body_text) for e, r in rows]


def ingest_bytes(session: Session, slug: str, data: bytes, filename: str) -> IngestResult:
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp.write(data)
        path = Path(tmp.name)
    try:
        return ingest_file(session, slug, path, filename=filename)
    finally:
        path.unlink(missing_ok=True)


def ingest_file(session: Session, slug: str, path: str | Path, filename: str | None = None) -> IngestResult:
    """Parse `path` and store it as the next version of document `slug`.

    Re-ingesting a file identical (sha256) to the *latest* version is a no-op
    that returns that version, so retries and double uploads are harmless.
    """
    path = Path(path)
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    doc = get_or_create_document(session, slug)
    prev_version = latest_version(session, doc.id)
    if prev_version is not None and prev_version.file_sha256 == digest:
        return IngestResult(prev_version, created=False)

    settings = get_settings()
    parsed = parse_pdf(path, ocr_mode=settings.ocr_mode, ocr_crosscheck=settings.ocr_crosscheck)
    number = (session.scalar(select(func.max(DocumentVersion.version_number))
                             .where(DocumentVersion.document_id == doc.id)) or 0) + 1
    version = DocumentVersion(document_id=doc.id, version_number=number,
                              source_filename=filename or path.name, file_sha256=digest,
                              title=parsed.title, parse_warnings=parsed.warnings,
                              parse_stats=parsed.stats)
    session.add(version)
    session.flush()
    _store_tree(session, doc, version, prev_version, parsed)
    doc.title = parsed.title
    session.commit()
    return IngestResult(version, created=True)


def _store_tree(session: Session, doc: Document, version: DocumentVersion,
                prev_version: DocumentVersion | None, parsed: ParseResult) -> None:
    prev_nodes = _previous_nodes(session, prev_version) if prev_version else []
    matches, report = match_versions(prev_nodes, parsed)
    prev_rev_by_logical = {}
    if prev_version is not None:
        for e in session.scalars(select(TreeEntry).where(TreeEntry.document_version_id == prev_version.id)):
            prev_rev_by_logical[e.logical_node_id] = e.revision_id

    logical_by_key: dict[str, int] = {}
    for node in parsed.nodes:  # pass 1: logical ids
        m = matches[node.key]
        if m.logical_id is None:
            ln = LogicalNode(document_id=doc.id, first_version_id=version.id, origin_key=node.key)
            session.add(ln)
            session.flush()
            logical_by_key[node.key] = ln.id
        else:
            logical_by_key[node.key] = m.logical_id

    for node in parsed.nodes:  # pass 2: revisions + placement
        m = matches[node.key]
        lid = logical_by_key[node.key]
        prev_rev_id = prev_rev_by_logical.get(lid)
        if m.status in ("unchanged", "moved") and prev_rev_id is not None:
            revision_id = prev_rev_id  # same content: reuse, do not duplicate
        else:
            rev = NodeRevision(logical_node_id=lid, title=node.title, body_text=node.body_text,
                               blocks=[b.to_dict() for b in node.blocks],
                               content_hash=node.content_hash, created_in_version_id=version.id,
                               previous_revision_id=prev_rev_id)
            session.add(rev)
            session.flush()
            revision_id = rev.id
        session.add(TreeEntry(
            document_version_id=version.id, logical_node_id=lid, revision_id=revision_id,
            parent_logical_node_id=logical_by_key.get(node.parent_key) if node.parent_key else None,
            section_key=node.key, section_number=node.number, level=node.level, depth=node.depth,
            order_index=node.order_index, page_start=node.page_start, page_end=node.page_end,
            warnings=node.warnings, refs=node.refs, change_status=m.status if prev_version else "added",
            match_rule=m.rule,
        ))
    report["logical_ids"] = logical_by_key
    version.matching_report = report if prev_version else {"first_version": True}
    session.flush()
