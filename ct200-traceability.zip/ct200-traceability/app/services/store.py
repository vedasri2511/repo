"""NoSQL store for LLM generations.

Generations are document-shaped (variable number of test cases, raw attempt
logs, embedded source snapshots) and are written once, read many times, and
queried by selection, node or request key. That fits MongoDB well; a JSON
file store with the same interface is provided for running without a Mongo
server (default when MONGO_URI is unset; see the approach doc for why that is
acceptable here and where it is not).

Each stored generation embeds the exact source text it was produced from, so it
stays self-describing even if the SQL database is rebuilt or the document is
re-versioned many times.
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from pathlib import Path
from typing import Any, Optional, Protocol

from app.config import get_settings


class GenerationStore(Protocol):
    def insert(self, doc: dict) -> str: ...
    def update(self, gen_id: str, fields: dict) -> None: ...
    def get(self, gen_id: str) -> Optional[dict]: ...
    def find(self, *, selection_id: Optional[int] = None, node_id: Optional[int] = None,
             request_key: Optional[str] = None) -> list[dict]: ...


def new_id() -> str:
    return uuid.uuid4().hex


class JsonStore:
    """Single JSON file, whole-file rewrite with atomic rename. Fine for a demo
    and a few thousand generations; not for concurrent multi-process writers."""

    _lock = threading.Lock()

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        return json.loads(self.path.read_text() or "[]")

    def _save(self, docs: list[dict]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(docs, indent=1, default=str))
        os.replace(tmp, self.path)

    def insert(self, doc: dict) -> str:
        with self._lock:
            docs = self._load()
            doc = {**doc, "_id": doc.get("_id") or new_id()}
            docs.append(doc)
            self._save(docs)
            return doc["_id"]

    def update(self, gen_id: str, fields: dict) -> None:
        with self._lock:
            docs = self._load()
            for d in docs:
                if d["_id"] == gen_id:
                    d.update(fields)
                    break
            else:
                raise KeyError(gen_id)
            self._save(docs)

    def get(self, gen_id: str) -> Optional[dict]:
        return next((d for d in self._load() if d["_id"] == gen_id), None)

    def find(self, *, selection_id=None, node_id=None, request_key=None) -> list[dict]:
        out = []
        for d in self._load():
            if selection_id is not None and d.get("selection_id") != selection_id:
                continue
            if request_key is not None and d.get("request_key") != request_key:
                continue
            if node_id is not None and node_id not in {s["node_id"] for s in d.get("sources", [])}:
                continue
            out.append(d)
        return sorted(out, key=lambda d: d.get("created_at", ""))


class MongoStore:
    def __init__(self, uri: str, db: str, client: Any = None):
        if client is None:
            from pymongo import MongoClient

            client = MongoClient(uri, serverSelectionTimeoutMS=3000)
        self.col = client[db]["generations"]
        self.col.create_index("request_key")
        self.col.create_index("selection_id")
        self.col.create_index("sources.node_id")

    def insert(self, doc: dict) -> str:
        doc = {**doc, "_id": doc.get("_id") or new_id()}
        self.col.insert_one(doc)
        return doc["_id"]

    def update(self, gen_id: str, fields: dict) -> None:
        res = self.col.update_one({"_id": gen_id}, {"$set": fields})
        if res.matched_count == 0:
            raise KeyError(gen_id)

    def get(self, gen_id: str) -> Optional[dict]:
        return self.col.find_one({"_id": gen_id})

    def find(self, *, selection_id=None, node_id=None, request_key=None) -> list[dict]:
        q: dict[str, Any] = {}
        if selection_id is not None:
            q["selection_id"] = selection_id
        if request_key is not None:
            q["request_key"] = request_key
        if node_id is not None:
            q["sources.node_id"] = node_id
        return list(self.col.find(q).sort("created_at", 1))


_store: Optional[GenerationStore] = None
_store_key: Optional[tuple] = None


def get_store() -> GenerationStore:
    global _store, _store_key
    s = get_settings()
    key = (s.generation_store, s.mongo_uri, s.mongo_db, s.json_store_path)
    if _store is None or _store_key != key:
        if s.generation_store == "mongo":
            _store = MongoStore(s.mongo_uri, s.mongo_db)
        elif s.generation_store == "json":
            _store = JsonStore(s.json_store_path)
        else:
            raise ValueError(f"unknown GENERATION_STORE {s.generation_store!r}")
        _store_key = key
    return _store


def set_store(store: GenerationStore) -> None:
    """Inject a store (tests use mongomock through this)."""
    global _store, _store_key
    s = get_settings()
    _store = store
    _store_key = (s.generation_store, s.mongo_uri, s.mongo_db, s.json_store_path)
