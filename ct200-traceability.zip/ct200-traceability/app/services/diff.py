"""Lightweight diff + change classification between two revisions of a node.

The classification answers the assignment's question "does a one-word wording
change get treated the same as a changed pressure threshold?" — no:

  substantive : a *normative token* was added, removed or changed. Normative
                tokens are numbers (with units, %, ranges), comparators
                (<, >, ≥, ≤, ±), error codes (E3), and modal / negation words
                (must, shall, should, may, not, never, cannot, only, except …).
  editorial   : words changed but no normative token did.
  cosmetic    : only punctuation/case differs.

It is a triage hint, not a guarantee. Known blind spots: "within 2 seconds" ->
"within 2 minutes" *is* caught (unit token changes), but "is intended for
adults" -> "is intended for children" is only "editorial", and a new sentence
that adds a requirement without numbers or modal verbs is also "editorial".
For that reason every hash change is still reported as stale; severity only
decides how loudly.
"""
from __future__ import annotations

import difflib
import re
from collections import Counter

from app.parser.normalize import normalize_text

_UNIT = r"(?:%|(?:mmHg|bpm|cm|mm|kPa|V|s|sec|seconds?|minutes?|min|hours?|h|years?|days?|ms|cycles?|readings?|measurements?)\b)"
NUMBER_RE = re.compile(
    rf"(?:[<>≥≤±=]\s*)?\d+(?:[.,]\d+)?(?:\s*[–\-—]\s*\d+(?:[.,]\d+)?)?(?:\s*{_UNIT})?",
)
CODE_RE = re.compile(r"\bE\d+(?:\s*[–\-—]\s*E\d+)?\b")
COMPARATOR_RE = re.compile(r"[<>≥≤±]")
MODAL_WORDS = {
    "must", "shall", "should", "may", "can", "cannot", "not", "no", "never", "only",
    "except", "unless", "always", "required", "requires", "prohibited", "do", "does",
    "before", "after", "within", "exceeds", "below", "above", "at least", "at most",
}


def normative_tokens(text: str) -> Counter:
    t = normalize_text(text)
    toks: Counter = Counter()
    for m in CODE_RE.finditer(t):
        toks[re.sub(r"\s+", "", m.group(0)).replace("—", "–").replace("-", "–")] += 1
    no_codes = CODE_RE.sub(" ", t)
    for m in NUMBER_RE.finditer(no_codes):
        tok = re.sub(r"\s+", " ", m.group(0)).strip().replace("—", "–")
        toks[tok] += 1
    for m in COMPARATOR_RE.finditer(no_codes):
        toks[f"cmp:{m.group(0)}"] += 1
    words = re.findall(r"[a-z']+", t.lower())
    for w in words:
        if w in MODAL_WORDS:
            toks[f"word:{w}"] += 1
    return toks


def word_ops(old: str, new: str, limit: int = 12) -> list[dict]:
    a, b = normalize_text(old).split(), normalize_text(new).split()
    ops = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        ops.append({"op": tag, "old": " ".join(a[i1:i2]), "new": " ".join(b[j1:j2])})
        if len(ops) >= limit:
            ops.append({"op": "truncated", "old": "", "new": ""})
            break
    return ops


def classify(old_title: str, old_body: str, new_title: str, new_body: str) -> dict:
    """Diff summary between two revisions of the same logical node."""
    old_full, new_full = f"{old_title}\n{old_body}", f"{new_title}\n{new_body}"
    if normalize_text(old_full) == normalize_text(new_full):
        return {"changed": False, "severity": "none", "summary": "no change", "ops": []}
    before, after = normative_tokens(old_full), normative_tokens(new_full)
    removed = sorted((before - after).elements())
    added = sorted((after - before).elements())
    if removed or added:
        severity = "substantive"
    elif re.sub(r"\W", "", old_full.lower()) == re.sub(r"\W", "", new_full.lower()):
        severity = "cosmetic"
    else:
        severity = "editorial"
    ops = word_ops(old_body, new_body)
    if normalize_text(old_title) != normalize_text(new_title):
        ops.insert(0, {"op": "title", "old": old_title, "new": new_title})
    ratio = difflib.SequenceMatcher(a=normalize_text(old_body), b=normalize_text(new_body)).ratio()
    parts = []
    for o in ops[:4]:
        if o["op"] == "replace":
            parts.append(f"'{o['old']}' → '{o['new']}'")
        elif o["op"] == "insert":
            parts.append(f"added '{o['new'][:80]}'")
        elif o["op"] == "delete":
            parts.append(f"removed '{o['old'][:80]}'")
        elif o["op"] == "title":
            parts.append(f"title '{o['old']}' → '{o['new']}'")
    return {
        "changed": True,
        "severity": severity,
        "similarity": round(ratio, 3),
        "normative_removed": removed,
        "normative_added": added,
        "summary": "; ".join(parts) + (" …" if len(ops) > 4 else ""),
        "ops": ops,
    }
