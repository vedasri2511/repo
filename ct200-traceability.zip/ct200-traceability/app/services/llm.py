"""LLM provider clients.

All providers are asked for JSON output (provider JSON mode where available),
but nothing downstream trusts that: every response goes through the parser
and validator in generation.py.

Providers: groq, openrouter (OpenAI-compatible chat API), gemini, mock.
The mock is deterministic and builds grounded test cases from the prompt's
source text; ``LLM_MOCK_SCENARIO`` makes it misbehave for demos and tests.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from typing import Optional, Protocol

import httpx

from app.config import get_settings

DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "openrouter": "meta-llama/llama-3.3-70b-instruct:free",
    "gemini": "gemini-2.5-flash",
    "mock": "mock-grounded-v1",
}


class LLMError(Exception):
    def __init__(self, message: str, retryable: bool):
        super().__init__(message)
        self.retryable = retryable


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    latency_ms: int
    usage: Optional[dict] = None


class LLMClient(Protocol):
    provider: str
    model: str

    def complete(self, system: str, user: str) -> LLMResponse: ...


def _raise_for_status(r: httpx.Response) -> None:
    if r.status_code == 429 or r.status_code >= 500:
        raise LLMError(f"HTTP {r.status_code}: {r.text[:300]}", retryable=True)
    if r.status_code >= 400:
        raise LLMError(f"HTTP {r.status_code}: {r.text[:300]}", retryable=False)


class OpenAICompatibleClient:
    URLS = {
        "groq": "https://api.groq.com/openai/v1/chat/completions",
        "openrouter": "https://openrouter.ai/api/v1/chat/completions",
    }

    def __init__(self, provider: str, api_key: str, model: str, timeout: float):
        self.provider, self.api_key, self.model, self.timeout = provider, api_key, model, timeout

    def complete(self, system: str, user: str) -> LLMResponse:
        t0 = time.monotonic()
        try:
            r = httpx.post(self.URLS[self.provider], timeout=self.timeout,
                           headers={"Authorization": f"Bearer {self.api_key}"},
                           json={"model": self.model, "temperature": 0.2,
                                 "response_format": {"type": "json_object"},
                                 "messages": [{"role": "system", "content": system},
                                              {"role": "user", "content": user}]})
        except httpx.HTTPError as e:
            raise LLMError(f"transport error: {e}", retryable=True) from e
        _raise_for_status(r)
        body = r.json()
        try:
            text = body["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as e:
            raise LLMError(f"unexpected response shape: {str(body)[:300]}", retryable=True) from e
        return LLMResponse(text, self.provider, self.model, int((time.monotonic() - t0) * 1000), body.get("usage"))


class GeminiClient:
    provider = "gemini"

    def __init__(self, api_key: str, model: str, timeout: float):
        self.api_key, self.model, self.timeout = api_key, model, timeout

    def complete(self, system: str, user: str) -> LLMResponse:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        t0 = time.monotonic()
        try:
            r = httpx.post(url, params={"key": self.api_key}, timeout=self.timeout, json={
                "systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "user", "parts": [{"text": user}]}],
                "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"},
            })
        except httpx.HTTPError as e:
            raise LLMError(f"transport error: {e}", retryable=True) from e
        _raise_for_status(r)
        body = r.json()
        try:
            parts = body["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts)
        except (KeyError, IndexError, TypeError) as e:
            # e.g. finishReason SAFETY with no content
            raise LLMError(f"no content in response: {str(body)[:300]}", retryable=True) from e
        return LLMResponse(text, self.provider, self.model, int((time.monotonic() - t0) * 1000),
                           body.get("usageMetadata"))


class MockLLM:
    """Deterministic stand-in for tests and offline demos.

    scenario:
      "good"       – 4 grounded test cases
      "flaky"      – first call returns prose + broken JSON, then good
      "ungrounded" – first call cites a section that is not in the prompt and
                     invents a quote, then good
      "garbage"    – never returns valid output
      "too_few"    – returns 2 cases every time
    ``responses`` (tests) overrides everything with a fixed script of raw strings.
    """

    provider = "mock"

    def __init__(self, scenario: str = "good", responses: Optional[list[str]] = None):
        self.model = DEFAULT_MODELS["mock"]
        self.scenario = scenario
        self.responses = list(responses) if responses is not None else None
        self.calls = 0

    def complete(self, system: str, user: str) -> LLMResponse:
        self.calls += 1
        if self.responses is not None:
            text = self.responses.pop(0) if self.responses else ""
            return LLMResponse(text, "mock", self.model, 0)
        sections = _sections_from_prompt(user)
        if self.scenario == "garbage":
            return LLMResponse("Sure! Here are some test ideas: 1) test the cuff", "mock", self.model, 0)
        if self.scenario == "flaky" and self.calls == 1:
            good = _good_cases(sections)
            return LLMResponse("Here you go:\n```json\n" + json.dumps(good)[:-40] + "\n```", "mock", self.model, 0)
        if self.scenario == "ungrounded" and self.calls == 1:
            good = _good_cases(sections)
            for c in good["test_cases"]:
                c["source_sections"] = ["9.9"]
                c["source_quote"] = "The device must withstand 500 mmHg indefinitely."
            return LLMResponse(json.dumps(good), "mock", self.model, 0)
        cases = _good_cases(sections)
        if self.scenario == "too_few":
            cases["test_cases"] = cases["test_cases"][:2]
        return LLMResponse(json.dumps(cases), "mock", self.model, 0)


_SECTION_RE = re.compile(r"^### SECTION (?P<num>\S+) — (?P<title>.+?)\n(?P<body>.*?)(?=^### |\Z)", re.M | re.S)


def _sections_from_prompt(user: str) -> list[tuple[str, str, str]]:
    return [(m["num"], m["title"].strip(), m["body"].strip()) for m in _SECTION_RE.finditer(user)]


def _good_cases(sections: list[tuple[str, str, str]]) -> dict:
    """Build 3-5 grounded cases: one per sentence/row that carries a number,
    cycling through the sections in the prompt."""
    with_numbers, others = [], []
    for num, title, body in sections:
        if body.startswith("(heading only"):
            continue
        lines = [l.strip() for l in re.split(r"(?<=[.;])\s+|\n", body) if len(l.strip()) > 15]
        for line in lines:
            (with_numbers if re.search(r"\d", line) else others).append((num, title, line))
    candidates = with_numbers + others
    if not candidates:
        candidates = [(num, title, body[:200] or title) for num, title, body in sections]
    while len(candidates) < 3:
        candidates = candidates + candidates
    cases = []
    for i, (num, title, line) in enumerate(candidates[:4], start=1):
        quote = line[:200]
        cases.append({
            "title": f"Verify {title.lower()} requirement #{i}",
            "objective": f"Confirm the device behaves as stated in section {num}.",
            "test_type": "boundary" if re.search(r"\d", line) else "functional",
            "priority": "high" if re.search(r"pressure|E\d|alarm|deflat", line, re.I) else "medium",
            "preconditions": ["Device powered on with fresh batteries", "Standard cuff connected"],
            "steps": [f"Set up the condition described: {quote}", "Observe the device display and behaviour"],
            "expected_result": f"Device behaviour matches: {quote}",
            "source_sections": [num],
            "source_quote": quote,
        })
    return {"test_cases": cases}


def get_client(override: Optional[LLMClient] = None) -> LLMClient:
    if override is not None:
        return override
    s = get_settings()
    provider = s.llm_provider.lower()
    model = s.llm_model or DEFAULT_MODELS.get(provider, "")
    if provider == "mock":
        import os

        return MockLLM(os.getenv("LLM_MOCK_SCENARIO", "good"))
    if not s.llm_api_key:
        raise LLMError(f"LLM_PROVIDER={provider} but LLM_API_KEY is not set", retryable=False)
    if provider in ("groq", "openrouter"):
        return OpenAICompatibleClient(provider, s.llm_api_key, model, s.llm_timeout_s)
    if provider == "gemini":
        return GeminiClient(s.llm_api_key, model, s.llm_timeout_s)
    raise LLMError(f"unknown LLM_PROVIDER {provider!r}", retryable=False)
