"""End-to-end demo of the versioning + staleness flow against a running server.

    uvicorn app.main:app --port 8000          # in one terminal
    python scripts/demo_flow.py               # in another

Uses a fresh document slug per run (ct200-demo-<timestamp>) so it can be
re-run without resetting the database. Works with LLM_PROVIDER=mock (default)
or a real provider configured on the *server*.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]


def banner(n: int, text: str) -> None:
    print(f"\n{'=' * 78}\n[{n}] {text}\n{'=' * 78}")


def show(obj, keys=None, limit=1200):
    if keys:
        obj = {k: obj.get(k) for k in keys}
    s = json.dumps(obj, indent=2, ensure_ascii=False)
    print(s if len(s) <= limit else s[:limit] + "\n  …")


class Api:
    def __init__(self, base: str):
        self.c = httpx.Client(base_url=base, timeout=180)

    def __call__(self, method: str, path: str, expect=(200, 201), **kw):
        r = self.c.request(method, path, **kw)
        if r.status_code not in expect:
            print(f"!! {method} {path} -> {r.status_code}: {r.text[:500]}")
            sys.exit(1)
        return r


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://127.0.0.1:8000")
    ap.add_argument("--slug", default=f"ct200-demo-{int(time.time())}")
    args = ap.parse_args()
    api, slug = Api(args.base_url), args.slug

    def upload(path: Path):
        with open(path, "rb") as f:
            return api("POST", f"/documents/{slug}/versions",
                       files={"file": (path.name, f, "application/pdf")}).json()

    def nid(number: str, version: int | None = None) -> int:
        params = {"q": number, "field": "heading"} | ({"version": version} if version else {})
        hits = api("GET", f"/documents/{slug}/search", params=params).json()
        return next(h["node_id"] for h in hits if h["section_number"] == number)

    banner(1, f"Ingest v1 (data/ct200_manual.pdf) as document '{slug}'")
    v1 = upload(ROOT / "data" / "ct200_manual.pdf")
    show(v1["version"], ["version", "node_count", "warning_count", "file_sha256"])
    report = api("GET", f"/documents/{slug}/versions/1").json()
    print("Parser warnings per node (structural irregularities found):")
    for key, ws in report["node_warnings"].items():
        for w in ws:
            print(f"  {key:8} {w}")

    banner(2, "Browse: top-level sections, a node, search")
    for s in api("GET", f"/documents/{slug}/sections").json():
        print(f"  node {s['node_id']:3}  {s['section_number']:3} {s['title']}")
    n42 = nid("4.2")
    node = api("GET", f"/nodes/{n42}").json()
    show(node, ["node_id", "version", "heading", "parent", "content_hash", "body_text"])
    hits = api("GET", f"/documents/{slug}/search", params={"q": "E3"}).json()
    print("search 'E3':", [(h["section_number"], h["matched_in"]) for h in hits])

    banner(3, "Create version-pinned selections on v1")
    sel_e3 = api("POST", "/selections", json={"document": slug, "name": "E3 overpressure",
                                              "node_ids": [nid("4.1"), n42], "version": 1}).json()
    sel_use = api("POST", "/selections", json={"document": slug, "name": "Intended use",
                                               "node_ids": [nid("1.1")], "version": 1}).json()
    sel_bat = api("POST", "/selections", json={"document": slug, "name": "Battery life",
                                               "node_ids": [nid("2.1.1.1")], "version": 1}).json()
    for s in (sel_e3, sel_use, sel_bat):
        print(f"  selection {s['selection_id']} '{s['name']}': "
              f"{[(n['section_number'], 'v%d' % n['version']) for n in s['nodes']]}")

    banner(4, "Generate test cases (LLM) for each selection")
    gens = {}
    for s in (sel_e3, sel_use, sel_bat):
        r = api("POST", f"/selections/{s['selection_id']}/generations", expect=(200, 201, 502))
        g = r.json()
        if r.status_code == 502:
            print(f"  '{s['name']}': generation FAILED -> {g['detail']}")
            continue
        gens[s["name"]] = g
        print(f"  '{s['name']}' -> {g['status']} ({g['provider']}/{g['model']}), staleness={g['staleness']['status']}")
        for c in g["test_cases"]:
            print(f"      {c['case_id']} [{c['test_type']}/{c['priority']}] {c['title']}")
            print(f"          expect: {c['expected_result'][:110]}")
    r = api("POST", f"/selections/{sel_e3['selection_id']}/generations")
    print(f"\n  same selection again -> HTTP {r.status_code}, reused={r.json()['reused']} "
          f"(same generation id: {r.json()['generation_id'] == gens.get('E3 overpressure', {}).get('generation_id')})")

    banner(5, "Re-ingest the modified manual (data/ct200_manual_v2.pdf) as version 2")
    v2 = upload(ROOT / "data" / "ct200_manual_v2.pdf")
    show(v2["changes_vs_previous"], ["counts", "modified", "added", "removed", "rules"])
    again = upload(ROOT / "data" / "ct200_manual_v2.pdf")
    print(f"  uploading v2 again -> created={again['created']} (version {again['version']['version']})")

    banner(6, "Has node 4.2 changed across versions?")
    ch = api("GET", f"/nodes/{n42}/changes").json()
    for t in ch["transitions"]:
        show(t, ["from_version", "to_version", "severity", "summary", "normative_removed", "normative_added"])
    same = api("GET", f"/nodes/{nid('1.1')}/changes").json()
    print(f"  node 1.1 changed_in_any_version = {same['changed_in_any_version']}")

    banner(7, "Old selection still resolves to the exact v1 text")
    s = api("GET", f"/selections/{sel_e3['selection_id']}").json()
    for n in s["nodes"]:
        print(f"  {n['section_number']} pinned v{n['version']} current_in_latest={n['current_in_latest']}")
    e3_row = [l for l in s["nodes"][1]["body_text"].splitlines() if l.startswith("E3")]
    print(f"  pinned 4.2 E3 row: {e3_row}")

    banner(8, "Retrieve generations: staleness evaluated against the latest version")
    for s in (sel_e3, sel_use, sel_bat):
        for g in api("GET", "/generations", params={"selection_id": s["selection_id"]}).json():
            st = g["staleness"]
            print(f"\n  '{s['name']}' ({g['generation_id'][:8]}): {st['status'].upper()}")
            print(f"    {st['summary']}")
            for src in st["sources"]:
                print(f"    - {src['section_number']}: {src['status']} ({src['severity']}) {src['reason'][:120]}")
            for c in st["test_cases"]:
                flag = f" asserts removed values {c['mentions_values_no_longer_in_source']}" \
                    if c["mentions_values_no_longer_in_source"] else ""
                print(f"    · {c['case_id']}: {c['status']}{flag}")

    banner(9, "Retrieve by node id (4.2)")
    for g in api("GET", f"/nodes/{n42}/generations").json():
        print(f"  generation {g['generation_id'][:8]} from selection '{g['selection_name']}' "
              f"-> {g['staleness']['status']}")

    banner(10, "New selection on v2 for the same node: fresh, current test cases")
    new_sel = api("POST", "/selections", json={"document": slug, "name": "E3 overpressure (v2)",
                                               "node_ids": [n42]}).json()
    r = api("POST", f"/selections/{new_sel['selection_id']}/generations", expect=(200, 201, 502))
    g = r.json()
    print(f"  pinned to v{new_sel['nodes'][0]['version']}; generation {g.get('status')}, "
          f"staleness={g.get('staleness', {}).get('status')}")
    print("\nDone.")


if __name__ == "__main__":
    main()
