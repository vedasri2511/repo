"""Dump every text line of a PDF with font, size and x-position.

This is the first thing I ran against the CT-200 manual, before writing any
parsing logic. It shows what the text layer actually contains (fonts, sizes,
indentation) so heading/list/table rules are based on evidence, not on how the
first page looks.

Usage: python scripts/dump_pdf_layout.py data/ct200_manual.pdf
"""
import sys

import pdfplumber


def main(path: str) -> None:
    with pdfplumber.open(path) as pdf:
        print(f"===== {path}: {len(pdf.pages)} pages")
        for i, page in enumerate(pdf.pages, start=1):
            print(f"--- page {i} size={page.width}x{page.height} chars={len(page.chars)} "
                  f"images={len(page.images)} rects={len(page.rects)}")
            words = page.extract_words(extra_attrs=["fontname", "size"], use_text_flow=True)
            lines: dict[int, list] = {}
            for w in words:
                lines.setdefault(round(w["top"]), []).append(w)
            for top in sorted(lines):
                ws = lines[top]
                fonts = sorted({(w["fontname"], round(w["size"], 1)) for w in ws})
                text = " ".join(w["text"] for w in ws)
                print(f"{top:4d} x0={ws[0]['x0']:5.1f} {fonts} | {text}")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        main(p)
