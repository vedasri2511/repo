"""Validation harness for the parser (run after every parser change).

Checks, in order:
  1. Prints the reconstructed tree (number, title, parent, block kinds) so it
     can be compared by eye with the rendered PDF.
  2. Token coverage: every word in the PDF text layer must appear in the parsed
     output (titles + bodies), and nothing may appear twice. Lost or duplicated
     content is reported, never silently accepted.
  3. Cross-version diff: for v1 vs v2, lists every node whose content hash
     differs, with a word diff. Expected differences are in
     docs/pdf_inspection_notes.md; anything else is a parser bug (layout leaking
     into content).

Usage: python scripts/validate_parse.py data/ct200_manual.pdf data/ct200_manual_v2.pdf
"""
from __future__ import annotations

import difflib
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pdfplumber  # noqa: E402

from app.parser import parse_pdf  # noqa: E402
from app.parser.extract import fix_glyphs  # noqa: E402
from app.parser.normalize import normalize_text  # noqa: E402


def tokens(text: str) -> Counter:
    # "1." (printed heading number) and "1" (rendered node.number) are the same token
    return Counter(t[:-1] if t[:-1].isdigit() and t.endswith(".") else t
                   for t in normalize_text(fix_glyphs(text)).replace("|", " ").split())


def pdf_tokens(path: str) -> Counter:
    """Reference token bag from pdfplumber's own extract_text (y_tolerance=3),
    deliberately not the parser's line builder, so the check is independent."""
    c: Counter = Counter()
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            c += tokens(page.extract_text() or "")
    return c


def show_tree(result) -> None:
    print(f"TITLE: {result.title!r}")
    for n in result.nodes[1:]:
        kinds = ",".join(b.kind for b in n.blocks) or "-"
        warn = f"  !! {'; '.join(n.warnings)}" if n.warnings else ""
        print(f"{'  ' * (n.level - 1)}{n.key:<8} {n.title:<42} parent={n.parent_key:<6} "
              f"p{n.page_start}-{n.page_end} [{kinds}]{warn}")
    for w in result.warnings:
        print(f"DOC WARNING: {w}")


def coverage(path: str, result) -> None:
    expected = pdf_tokens(path)
    produced: Counter = Counter()
    produced += tokens(result.title)
    for n in result.nodes[1:]:
        produced += tokens(n.heading) + tokens(n.body_text)
    # list renumbering re-emits "1." etc. and table rendering adds no words
    missing = expected - produced
    extra = produced - expected
    print(f"coverage: {sum(expected.values())} tokens in PDF, "
          f"{sum(missing.values())} missing, {sum(extra.values())} extra")
    if missing:
        print("  MISSING:", dict(missing.most_common(20)))
    if extra:
        print("  EXTRA:  ", dict(extra.most_common(20)))


def cross_version(r1, r2) -> None:
    a, b = r1.by_key(), r2.by_key()
    for key in sorted(set(a) | set(b), key=lambda k: (k == "root", k)):
        if key == "root":
            continue
        if key not in a:
            print(f"ADDED   {key} {b[key].title}")
            continue
        if key not in b:
            print(f"REMOVED {key} {a[key].title}")
            continue
        if a[key].content_hash != b[key].content_hash:
            wa = normalize_text(a[key].body_text).split()
            wb = normalize_text(b[key].body_text).split()
            ops = [
                f"{tag}: {' '.join(wa[i1:i2])!r} -> {' '.join(wb[j1:j2])!r}"
                for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=wa, b=wb).get_opcodes()
                if tag != "equal"
            ]
            print(f"CHANGED {key} {a[key].title}")
            for op in ops:
                print(f"    {op}")


OCR_MODE = "auto"


def main(paths: list[str]) -> None:
    results = []
    for p in paths:
        print(f"\n==================== {p}")
        r = parse_pdf(p, ocr_mode=OCR_MODE)
        show_tree(r)
        if r.stats.get("paragraphs_joined_across_pages"):
            print("page-break joins:", r.stats["paragraphs_joined_across_pages"])
        coverage(p, r)
        results.append(r)
    if len(results) == 2:
        print("\n==================== v1 -> v2 content-hash differences")
        cross_version(*results)


if __name__ == "__main__":
    args = sys.argv[1:]
    if "--force-ocr" in args:
        OCR_MODE = "force"
        args.remove("--force-ocr")
    main(args)
