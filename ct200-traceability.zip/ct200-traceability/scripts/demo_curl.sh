#!/usr/bin/env bash
# Same v1 -> v2 staleness flow as demo_flow.py, with plain curl + jq.
# Usage: BASE=http://127.0.0.1:8000 DOC=ct200 ./scripts/demo_curl.sh
set -euo pipefail
BASE=${BASE:-http://127.0.0.1:8000}
DOC=${DOC:-ct200-curl-$(date +%s)}
cd "$(dirname "$0")/.."

nid() {  # section number -> node id
  curl -s "$BASE/documents/$DOC/search?field=heading&q=$1" | jq -r --arg n "$1" '.[] | select(.section_number==$n) | .node_id'
}

echo "== 1. ingest v1";  curl -s -F file=@data/ct200_manual.pdf "$BASE/documents/$DOC/versions" | jq '{created, version: .version.version, nodes: .version.node_count}'
echo "== 2. top-level sections"; curl -s "$BASE/documents/$DOC/sections" | jq -c '.[] | [.node_id, .section_number, .title]'
N42=$(nid 4.2); N11=$(nid 1.1)
echo "== 3. node 4.2 (id $N42)"; curl -s "$BASE/nodes/$N42" | jq '{heading, version, content_hash, children: [.children[].title], warnings}'
echo "== 4. search 'battery'"; curl -s "$BASE/documents/$DOC/search?q=battery" | jq -c '.[] | [.section_number, .matched_in]'
echo "== 5. selection pinned to v1"
SEL=$(curl -s -X POST "$BASE/selections" -H 'content-type: application/json' \
  -d "{\"document\":\"$DOC\",\"name\":\"E3\",\"node_ids\":[$N42],\"version\":1}" | jq -r .selection_id)
echo "selection $SEL"
echo "== 6. generate"; curl -s -X POST "$BASE/selections/$SEL/generations" | jq '{status, reused, cases: [.test_cases[].title], staleness: .staleness.status}'
echo "== 7. generate again (reused)"; curl -s -X POST "$BASE/selections/$SEL/generations" | jq '{reused, generation_id}'
echo "== 8. ingest v2"; curl -s -F file=@data/ct200_manual_v2.pdf "$BASE/documents/$DOC/versions" | jq '.changes_vs_previous | {counts, modified, added}'
echo "== 9. node 4.2 changes"; curl -s "$BASE/nodes/$N42/changes" | jq '.transitions[] | {from_version, to_version, severity, summary}'
echo "== 10. retrieve generations for the selection (staleness)"
curl -s "$BASE/generations?selection_id=$SEL" | jq '.[] | {generation_id, staleness: {status: .staleness.status, summary: .staleness.summary, cases: [.staleness.test_cases[] | {case_id, status, mentions_values_no_longer_in_source}]}}'
echo "== 11. retrieve by node id"; curl -s "$BASE/nodes/$N42/generations" | jq -c '.[] | [.generation_id, .staleness.status]'
echo "== 12. pinned selection still shows v1 text"; curl -s "$BASE/selections/$SEL" | jq -r '.nodes[0] | "v\(.version) current_in_latest=\(.current_in_latest)\n\(.body_text)"' | grep -E "^v|E3"
