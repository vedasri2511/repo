# CT-200 PDF inspection notes

Written before any parser code, from `scripts/dump_pdf_layout.py`, rendered-page
checks and a first Tesseract run. These notes drive the parser rules.

## What the files are

| | `ct200_manual.pdf` (v1) | `ct200_manual_v2.pdf` (v2) |
|---|---|---|
| Pages | 6 (A5-ish, 420x595 pt) | 7 |
| Text layer | Yes, every page | Yes, every page |
| Images | None | None |
| Tables | Drawn with filled rects (2.1, 4.2) | Same |

Fonts: Nimbus Sans Bold 22 (title), Bold 16.5 (chapter), Bold 12.9 (section),
Regular 11 (body). U+2011 non-breaking hyphens are rendered from a fallback font
(Noto Serif).

## Structural irregularities found

1. **Heading font size is not a reliable level signal.** `3.2 Cuff Inflation
   Sequence` and `2.1.1.1 Battery Life…` are Bold **11 pt** (body size), while
   their siblings are 12.9 pt. A size-based classifier would demote 3.2 to body
   text or mis-level it.
2. **Skipped level.** `2.1.1.1` appears directly under `2.1`; there is no `2.1.1`.
   Its numbering says depth 4, but its real parent is `2.1`.
3. **Out-of-order sections.** `3.4 Auto Shutoff` appears *before* `3.3 Result
   Display and Classification`.
4. **Duplicate heading text.** `4.2 Error Codes` and `7.1 Error Codes` share a
   title under different parents (and 7.1 refers back to 4.2).
5. **Numbered list that looks like headings.** Section 3.3 contains `1. Normal: …`
   to `5. Hypertensive Crisis: …`. These match the `N. Title` chapter pattern.
   They differ by font (Regular, not Bold) and indent (x=51 vs the 33 margin);
   item 5 wraps to a continuation line at x=63.
6. **Inline cross-references that look like section numbers.** "see 2.1, 4.3",
   "Section 4.2". They must not become headings or parent links.
7. **Tables with multi-line cells.** 4.2 Error Codes has cells wrapping onto 2–3
   lines; the naive line view interleaves columns ("E2 Motion artifact detected
   Aborts measurement, displays / during measurement E2, prompts retry").
8. **Spurious nested tables.** `pdfplumber.find_tables()` returns the real table
   plus several tiny "tables" built from cell-background rects inside it.
9. **Hyphen glyph on a different baseline.** The U+2011 glyphs sit ~0.06 pt higher
   than the surrounding text. Grouping words by rounded `top` puts them on
   their own "line": v1 §5.1 reads "The CT 200 stores … non volatile" plus a
   stray "‑ ‑" line, and v2 §4.3 loses the hyphen in "user‑configurable". Because
   this depends on where page layout lands, it would show up as a *false content
   change* between versions.
10. **Content split across page breaks.** Chapter headings sit at the foot of a
    page with their first section on the next one (v1 "2." → "2.1"), and
    paragraphs continue across pages (v1 §3.1, v2 §4.3, §6.1, §8.1). Naive
    `extract_text()` glues "Specifications" + "2.1 General Specifications" into one
    line.
11. **Multi-line title** (3 lines, 22 pt) before section 1.
12. **Page layout differs between v1 and v2** because v2 adds text. Hashes must be
    computed on normalized text, never on line/page positions.

## Content oddities (not parser problems, but worth flagging to QA)

- §6.2 says "Anthropic recommends professional recalibration" although the
  manufacturer is CardioTrack. Kept verbatim.
- §3.3 classification bands overlap: "Stage 2: systolic ≥ 140" and "Crisis:
  systolic > 180".
- v2: §4.1 says the valve vents "within 2 seconds" but §4.2 E3 now says "within
  1.5 seconds".
- §1 says 200 readings across two profiles; §5.1 says 100 per profile
  (consistent, but two places to update).

## v1 → v2 changes (by eye, used later as the matcher's ground truth)

| Section | Change |
|---|---|
| 2.1.1.1 | 300 → 250 cycles, 15% → 10%, added "revised downward…" clause |
| 3.2 | 40 → 30 mmHg increments, added sentence about the change |
| 4.2 | E3 deflate 2 s → 1.5 s; new E6 row |
| 4.3 | "E1–E5" → "E1–E6" |
| 5.3 | New section "Data Export" |
| all others | Unchanged text, different page positions |

## OCR check (Tesseract 5, 300 dpi)

Headings and body text come out well, but OCR **silently corrupts
safety-relevant tokens**: `≥ 140` became `= 140`, `E1–E5` became `E1—E5`,
and list numbers 1–5 were read as a separate garbage column ("aRWN —").
It also loses bold/size information. Decision: use the embedded text layer as the
source of truth, and use OCR for (a) pages with no text layer and (b) an
automatic cross-check that flags pages where the text layer and OCR disagree.
