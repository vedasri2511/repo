# Approach Document — CT-200 Traceability API

## 1. What the system does

```
 PDF ──► parser ──► versioned tree (SQLite) ──► browse / search / diff API
                          │
                          ▼
             version-pinned selections ──► LLM ──► validation ──► generations (MongoDB / JSON)
                                                                       │
                                     staleness check at read time ◄────┘
                                     (pinned source hash vs latest version)
```

Results on the provided files:

* v1 parses into 28 nodes (title + 27 sections), v2 into 29. Every glyph on
  every page is assigned to exactly one block (5 759 / 5 759 in v2).
* Re-ingesting v2 links 28 nodes to their v1 identities: 24 unchanged
  (sharing the same stored revision), 4 modified (2.1.1.1, 3.2, 4.2, 4.3),
  1 added (5.3), 0 removed. That matches the diff I made by hand before
  writing the matcher.
* A generation created from v1 §4.2 is reported **stale** after v2, naming the
  test case that still expects "within 2 seconds". One from §1.1 stays **current**.

## 2. Data model

**SQLite (SQLAlchemy)**

| Table | Role |
|---|---|
| `documents` | One row per document slug (`ct200`). |
| `document_versions` | One row per ingested PDF: version number, file SHA-256, parser warnings, parse stats, matching report vs. previous version. |
| `logical_nodes` | **Identity** of a section across versions. Its id is the `node_id` in the API. |
| `node_revisions` | **Immutable content**: title, body text, structured blocks (paragraph/list/table/figure), content hash, link to the previous revision. A new row is written only when content changes. |
| `tree_entries` | **Placement** of a logical node in one version: section number, parent, level/depth, order, pages, parser warnings, cross-references, change status, matcher rule used. |
| `selections`, `selection_items` | Named selection; each item pins (logical node, version, revision, content hash). |

Why split identity, content and placement:

* "Unchanged nodes are the same logical node, not duplicated": an unchanged
  section in v2 points at the **same `node_revisions` row** as in v1. Only 5 new
  revisions were written for v2.
* "Old selections resolve to the exact text": revisions are never updated and a
  version's tree entries are never rewritten. A selection item therefore always
  resolves to the same bytes.
* A section can move or be renumbered without a content change (placement
  changes, revision reused), or change content in place (new revision, same
  placement). Both are representable.

`content_hash` = SHA-256 of the normalized title + normalized body of the node
itself (not its children). Normalization collapses whitespace and maps
equivalent glyphs (U+2011 non-breaking hyphen → `-`, curly quotes, NBSP), so
line breaks, page breaks and glyph substitutions never change a hash. Section
numbers are excluded so a pure renumbering is reported as a move, not a content
change. Symbols that carry meaning (`≥`, `±`, `–`) are kept.

**NoSQL (generations)**: one document per generation, embedding the selection
id, request key, prompt version, provider/model, status, **a snapshot of every
source node** (node id, version, revision id, content hash, full text), the
validated test cases, and every raw LLM attempt with its errors. Each
generation is self-describing: it still says exactly what it was generated from
even if the SQL side were rebuilt.

## 3. PDF parsing

### 3.1 Inspection first

Before writing parser code I dumped every line with font, size and x-position
(`scripts/dump_pdf_layout.py`) and ran Tesseract on rendered pages. Findings are
in `docs/pdf_inspection_notes.md`. The important facts:

* Both PDFs have a complete embedded text layer, no images, tables drawn with
  filled rectangles.
* Fonts: Bold 22 (title), Bold 16.5 (chapters), Bold 12.9 (sections), Regular 11
  (body), but **not consistently** (see 3.3).

### 3.2 Approach: text layer first, OCR as fallback and cross-check

The brief asks for an OCR-based pipeline. I tested Tesseract 5 at 300 dpi on
these pages first. It read headings and prose well, but it **silently changed
safety-relevant content**:

* `systolic ≥ 140` became `systolic = 140`;
* `E1–E5` became `E1—E5`, `±3 mmHg` became `+3 mmHg`, `Class II` became `Class Il`;
* the list numbers 1–5 in §3.3 were read as a separate garbage line ("aRWN —");
* no font weight or size, so bold headings can't be told apart from body text.

For a medical-device QA tool, a parser that turns "≥" into "=" in a blood-pressure
threshold is worse than useless. So the pipeline is:

1. **Text layer** (pdfplumber), read at character level, as the source of truth
   when a page has one.
2. **OCR fallback** (Tesseract via pdf2image) for any page with fewer than 20
   extractable glyphs (`OCR_MODE=auto`). Lines from OCR carry `source="ocr"`, and
   every node built from them gets a warning that symbols and list numbers may
   be misread. Heading detection switches to margin/length/punctuation rules
   because OCR has no font weight.
3. **OCR cross-check** (`OCR_CROSSCHECK=true`): OCR every page and warn when OCR
   and the text layer agree on fewer than 90% of words. This catches text-layer
   problems such as broken ToUnicode maps, invisible text or garbage glyph
   mappings that would otherwise pass silently.

`OCR_MODE=force` runs the whole document through OCR. On v1 it rebuilds **the
same 27-node hierarchy with the same parents** (asserted in a test). The token
differences are exactly the symbol errors above (`docs/validation_logs/03_forced_ocr_v1.txt`).

### 3.3 Hierarchy reconstruction

* **Lines** are built from characters clustered by vertical overlap, not from
  pdfplumber's words. Spaces come from real space glyphs or visual gaps.
  Ligatures (ﬀ ﬁ ﬂ) are expanded.
* **Tables** come from `find_tables()`. Tables nested inside a larger table are
  discarded, because the cell-background rectangles produce fake mini-tables.
  Characters inside a table's bbox are removed from the line stream, multi-line
  cells are joined, and a table that continues on the next page with the same
  column count is merged.
* **Headings**: a line at the left margin, starting with a section number
  (`\d+(\.\d+)*`), and bold (or for OCR lines: short, not ending in sentence
  punctuation).
* **Level** = numbering depth. **Font size is never used for level.**
* **Parent** = the longest numeric prefix that exists *anywhere* in the document.
  This takes two passes, so a child printed before its parent still finds it.
* **Lists**: indented lines starting with `1.`, `a)`, `•`, `-`. Wrapped lines
  indented under an item are appended to it. Items keep their printed markers,
  so a list that skips a number stays visible.
* **Paragraphs**: consecutive lines with ≤ 6 pt of white space between them. A
  paragraph that reaches the bottom 72 pt of a page continues on the next page
  if the next page starts with body text.
* **Anomalies become warnings, never silent fixes.** They are stored per node
  and per version, and exposed at `GET /documents/{slug}/versions/{n}` and on
  every node.

### 3.4 Irregularities in the CT-200 PDF and how each is handled

| # | Irregularity (where) | Handling | Test |
|---|---|---|---|
| 1 | Heading at body font size: `3.2` and `2.1.1.1` are Bold 11 pt, siblings 12.9 pt | Level from numbering; warning "heading set at 11.0pt…" | `test_body_size_heading_is_still_a_heading` |
| 2 | Skipped level: `2.1.1.1` with no `2.1.1` | Attached to nearest existing ancestor `2.1`; `level`=4, `depth`=3; warning | `test_skipped_level_attaches_…` |
| 3 | Out-of-order: `3.4` printed before `3.3` | Both children of `3`, reading order kept (`3.1, 3.2, 3.4, 3.3`); warning on 3.3 | `test_out_of_order_sections_…` |
| 4 | Duplicate title: "Error Codes" at `4.2` and `7.1` | Keys come from numbers, so two distinct nodes with correct parents; informational warning | `test_duplicate_heading_title_gives_two_distinct_nodes…` |
| 5 | Numbered list looks like chapter headings ("1. Normal: …" in 3.3) | Not bold + indented, so list items; wrapped item 5 kept together | `test_numbered_list_items_are_not_headings` |
| 6 | Inline cross-references ("see 2.1, 4.3", "Section 4.2") | Mid-line, so never headings; stored as `refs`, dangling refs warned, used for related-change detection | `test_inline_cross_references_…` |
| 7 | Tables with multi-line cells (4.2) | Cell text joined per cell, not per visual line | `test_tables_are_extracted_…` |
| 8 | Spurious nested tables from cell rectangles | Discard tables contained in another table | same test (`len(rows) == 6`) |
| 9 | U+2011 hyphens drawn ~0.06 pt off the baseline in a fallback font | Character-level overlap clustering; hash normalization maps U+2011 → `-` | `test_displaced_hyphen_glyphs_…`, `test_layout_changes_alone_do_not_change_content_hashes` |
| 10 | Paragraphs and sections split across page breaks (v1 3.1; v2 4.3, 6.1, 8.1; chapter headings at page bottoms) | Bottom-of-page continuation rule; joins logged in `parse_stats` | `test_paragraph_continues_across_page_break`, `test_chapter_heading_at_page_bottom…` |
| 11 | Multi-line document title | Large-font lines before the first heading form the root title | `test_title_and_full_glyph_coverage` |
| 12 | Different page layout between v1 and v2 | Hashes ignore layout entirely | `test_layout_changes_alone_…` |

Synthetic tests cover cases this PDF doesn't contain but the rules must not get
silently wrong: a repeated section number (`1.1#2` + warning), a child before its
parent, an orphan section with no ancestor (attached to root + warning), a bold
unnumbered line, and a table split across pages.

### 3.5 What the first implementation got wrong, and how I found out

The first parser (commit `e16e3ce`) used pdfplumber words grouped by rounded
`top`, bold + number for headings, and everything else as paragraphs. I wrote a
validation harness, `scripts/validate_parse.py`, at the same time. It does three
checks:

1. prints the reconstructed tree with parents, pages, block kinds and warnings,
   for comparison against the rendered PDF;
2. **token coverage**: every word in pdfplumber's independent `extract_text()`
   must appear exactly once in the parsed output (no lost, no duplicated content);
3. **cross-version hash diff**: lists every node whose hash differs between v1
   and v2, with a word diff, checked against my manual diff of the two PDFs.

Run against the first parser (`docs/validation_logs/01_initial_parser.txt`), it showed:

* **False changes.** 4.3 and 5.1 were reported CHANGED with no real change. The
  diff showed only hyphens moving. That is the displaced U+2011 glyph: "CT‑200"
  became "CT 200" plus a stray "‑ ‑" line, depending on where the page break fell.
  This is the worst kind of bug for this system: every test case on those
  sections would have been flagged stale for nothing.
* Tables 2.1 and 4.2 flattened into interleaved lines ("E2 Motion artifact detected
  Aborts measurement, displays / during measurement E2, prompts retry").
* The §3.3 list merged into one paragraph.
* Paragraphs split at page breaks, so block structure differed by version.
* The harness itself had a bug: ligature glyphs (ﬀ, ﬁ) and missing newlines made
  ~165 tokens look missing. I fixed the harness before trusting its output.

After the rewrite (`docs/validation_logs/02_char_level_parser.txt`): 0 missing / 0
extra tokens on both files, and the cross-version diff shows exactly the five
expected changes. The glyph accounting is now built into the parser, so any
future gap shows up as a document warning instead of only in the harness.

A later bug was caught by the end-to-end demo, not by unit tests. The first
`demo_flow.py` run had two of three generations **fail validation**: the mock LLM
was quoting the prompt's closing instruction as if it were section text, and the
grounding check correctly rejected those quotes. Fix: an explicit
`### END OF REQUIREMENT TEXT` marker in the prompt, plus a regression test.

### 3.6 Parser limits I know about

* Headings are found by "bold + number at the margin". A heading that wraps onto
  two lines keeps only the first line as its title. The second line becomes body
  text, with a warning ("bold line not recognised as a numbered heading").
* Unnumbered headings ("Warnings", "Appendix") are not supported as headings.
  They are kept as text with the same warning.
* OCR mode can't rebuild tables (no ruling lines are used), so OCR'd tables come
  out as text lines, flagged as OCR content.
* A genuine paragraph break that falls exactly at a page break is merged into one
  paragraph. Hashes are unaffected (whitespace-normalized), only block boundaries.
* Figure handling (image + "Figure N" caption) is implemented but untested on
  real data, because these PDFs contain no images.

## 4. Versioning and node matching

Re-ingesting creates version N+1. Version N is never modified. An upload whose
SHA-256 equals the latest version's is a no-op that returns the existing version.

Matching runs between the new parse and the previous version, in rule order.
Each rule only considers nodes still unmatched:

| Rule | Condition | Catches |
|---|---|---|
| R1 | same section number **and** same normalized title | the normal case (28/28 here) |
| R2 | identical content hash, unique on both sides | renumbered/moved, text unchanged |
| R3 | same title, and the parents are already matched to each other; unique candidate | renumbered **and** edited |
| R4 | same number, title similarity ≥ 0.75 | small title edits |

Unmatched new nodes are *added*. Unmatched old nodes are *removed*. Multiple
candidates are reported as ambiguous and never guessed. Status per node:
`unchanged` (same hash, same place), `moved` (same hash, new number/parent),
`modified` (hash differs), `added`. Any linked pair whose bodies share less than
50% of their text is listed as **low confidence**.

**Why number-first.** The nodes that matter most are the ones that changed, and
their hash is by definition different, so hash-first can't link them. Title-only
fails on this very manual ("Error Codes" twice). Section numbers in a regulated
manual are stable identifiers people cite ("Section 4.2"), so they are the
strongest signal. Content and title rules are fallbacks for renumbering.

**Where it breaks**

* Renumbered **and** retitled **and** edited in one release → treated as delete + add.
  Traceability is lost, but loudly: old generations report "source removed".
* Split or merged sections are modelled as modified + added (or + removed), not
  as a split/merge. A test case on the original section will flag the shrunk
  section as changed, but won't point at the new sibling.
* Two sibling sections that swap numbers but keep their titles: R1 fails for
  both, then R2 (if unedited) or R3 re-links each by its title (correct). The
  reverse case is the dangerous one. If two sections keep their numbers and
  titles but their **bodies** are swapped or rewritten, R1 keeps identity by
  number and reports "modified", even though the requirement now lives
  elsewhere. The low-confidence flag (§4, < 50% shared body text) is what
  surfaces this.
* Matching is only against the immediately previous version. A section deleted in
  v2 and restored in v3 becomes a new logical node.

## 5. Selections

`POST /selections` takes `node_ids` (+ optional `version`, default latest) or
`items` with a per-node version. Each item stores (logical node, version,
revision id, content hash). `include_descendants` (default true) means selecting
chapter 4 includes 4.1–4.3 **as they were in the pinned version**.
`GET /selections/{id}` returns the exact pinned text plus `current_in_latest` per node.

Policy for submitting the same selection twice:

* same name + same pins → returns the existing selection (200) — retries are harmless;
* same name + different pins → **409**. Names identify selections; silently
  repointing "E3 overpressure" to new text would break every generation linked to it.
  A request without an explicit version resolves to the *latest* version. After a
  re-ingest, the "same" request therefore pins different text and gets a 409 that
  says so.
* different name + same pins → allowed. Names are labels, and two reviewers may
  select the same text for different purposes.

## 6. LLM generation

### 6.1 Prompt

* **System prompt**: role (QA engineer, regulated BP monitor), rules (use *only*
  the given text, never invent thresholds, prefer boundary/negative/safety cases,
  steps + measurable expected result), the exact JSON shape, 3–5 cases, JSON only.
* **User prompt**: the pinned text of each node as
  `### SECTION 4.2 — Error Codes` + body (tables rendered as `a | b | c` rows),
  closed by `### END OF REQUIREMENT TEXT`.
* Every case must cite `source_sections` and give a **verbatim `source_quote`**.
  That is what makes a case machine-checkable against the source, and it is the
  backbone of traceability.
* Provider JSON mode is requested (Groq/OpenRouter `response_format`, Gemini
  `responseMimeType`), but nothing relies on it.

### 6.2 Structured-output validation

Each reply goes through:

1. **JSON extraction** — tolerates code fences, prose around the JSON, a bare
   list, or one level of wrapping (`{"result": {"test_cases": …}}`). Fails with a
   specific reason: empty, no JSON, truncated, missing key, wrong type.
2. **Schema per case** (Pydantic `TestCaseIdea`) — required fields, lengths,
   enums (normalized case/spacing, so "Error Handling" is accepted), non-empty steps.
3. **Semantic checks**:
   * cited sections must be among the sections in the prompt;
   * `source_quote` must be grounded in a cited section: an exact substring after
     normalization, or ≥ 85% covered by the longest common run;
   * the quote may not contain any number/unit/code that the cited text lacks.
     Fuzzy grounding would otherwise accept "within 5 seconds" for "within 2
     seconds" in a long quote;
   * no duplicate titles.
4. Values in steps/expected result that the source does not state (e.g. "300 mmHg"
   in a boundary test for a 299 mmHg limit) are **kept but listed** in
   `values_not_in_source` for the reviewer. Rejecting them would forbid legitimate
   boundary tests.

### 6.3 What happens when the output is bad

* **Per-case acceptance.** Invalid cases are dropped, never stored as test cases.
  They go into the attempt log with reasons. If ≥ 3 valid cases remain, the
  generation is accepted (`accepted_with_warnings` if anything was dropped or
  truncated). More than 5 → first 5 kept, with a warning.
* **Fewer than 3 valid, or unparseable** → retry with a **repair prompt**
  containing the exact errors and the previous reply, up to `LLM_MAX_ATTEMPTS`
  (default 3). Transport errors, 429 and 5xx are retried with backoff. Auth/4xx
  fail immediately.
* **Still failing** → the generation is stored with status `failed`, all raw
  replies and errors, and the API returns **502** with its id.
  `GET /generations/{id}?include_attempts=true` shows what the model said. Failed
  generations are never returned as test cases and never reused.

Why: in a medical-device QA flow, a plausible test case built on a threshold the
manual never states is worse than no test case. A reviewer must be able to see
why output was rejected, so nothing is silently discarded.

### 6.4 Same selection submitted twice

The request key is SHA-256 of (selection id, sorted (node, revision, hash) of
every source, prompt version, provider, model).

* If an **accepted** generation with that key exists → it is returned with
  `reused: true` and no LLM call (HTTP 200).
* `{"force": true}` → a new generation that records `supersedes: <old id>`. Both
  remain retrievable.
* An identical request still `pending` (< 5 min) → 409.

Why: the output is non-deterministic. Silently stacking a second, different set
of test cases for the same text means two "answers" traced to one requirement,
and it burns free-tier quota. Regeneration is legitimate, so it is explicit.
Because the key includes the revision hashes, regenerating after the selection's
text changed is never blocked. That can only happen through a new selection,
since selections are pinned.

### 6.5 Providers

Groq and OpenRouter (OpenAI-compatible), Gemini, and a deterministic **mock**.
The mock builds grounded cases from the prompt text and has failure scenarios
(`flaky`, `ungrounded`, `garbage`, `too_few`) plus a scripted mode for tests.
The automated tests and the recorded demo output use the mock. Real providers
are used by setting `LLM_PROVIDER`/`LLM_API_KEY`, and the same validation path
applies to them.

## 7. Staleness / impact detection

Computed **at retrieval time** for every accepted generation, against the latest
version. For each source node:

* hash equal → `current`;
* node missing from latest → `stale` (removed);
* otherwise the old and new text are diffed and classified:
  * **substantive** — a *normative token* was added or removed: numbers with
    units/%/ranges ("2 seconds", "15%", "120–129"), error codes ("E6", "E1–E5"),
    comparators (`< > ≥ ≤ ±`), or modal/negation words (must, should, not, never,
    only, except, within, …) → `stale`;
  * **editorial** — words changed, no normative token did → `possibly_stale`;
  * **cosmetic** — only punctuation/case → `possibly_stale`.

The generation's status is the worst of its sources. Per test case the response
lists which of its cited sources changed, and **which values it asserts that no
longer appear in any of its cited sources' current text**. In the demo, the case
expecting "within 2 seconds" for E3 is named. Changes to sections that a source
cross-references (7.1 → "Section 4.2") are reported as `related_changes`, without
making the generation stale.

**Does a one-word change count the same as a changed pressure threshold?** No,
but both are surfaced. A threshold change is `stale`. A wording change is
`possibly_stale`, never `current`, because the classifier works on tokens, not
meaning. "adults" → "children" is one word and would be classed editorial, yet
it changes the intended population. "should" → "must" *is* caught (modal word).
Severity orders the review queue. It never hides a change.

## 8. Retrieval

* `GET /generations?selection_id=…` and/or `node_id=…` (node = any source,
  including descendants)
* `GET /nodes/{id}/generations`
* `GET /generations/{id}`

Every accepted generation is returned with its `staleness` block: overall
status, evaluated-against version, a human-readable summary, per-source
status/severity/diff, per-test-case status, related changes. The stored test
cases themselves are never modified.

## 9. Stack and deviations

As specified: FastAPI, Pydantic v2, SQLAlchemy 2 + SQLite, Git.

* **NoSQL.** MongoDB is supported (`MongoStore`, tested with mongomock) and used
  when `MONGO_URI` is set. If it isn't set, a **JSON file store** with the same
  interface is used, so the project runs without installing a database server.
  The JSON store rewrites a single file atomically under a process-local lock:
  fine for a single-process demo, wrong for multiple workers or large volumes.
  Use Mongo for anything beyond that.
* **pdfplumber + Tesseract** for parsing (reasons in 3.2). Tesseract and poppler
  are optional system dependencies, needed only for the OCR paths.

## 10. What I'd do differently with more time

* Run generation as a background job (queue + status polling) instead of inside
  the HTTP request, and enforce idempotency with a unique index on
  `(request_key, status=pending)` instead of a read-then-write check.
* Add a golden-file regression suite: the full expected tree for each manual
  version, checked into the repo, so any parser change shows a reviewable diff.
* Use an LLM or NLI model as a *second-opinion* change classifier for editorial
  changes (e.g. to catch "adults" → "children"), keeping the token rules as the
  floor.
* Persist the staleness verdict with a human "reviewed, still valid" override,
  so a reviewed editorial change stops showing as possibly stale.
* Match against all historical versions (to catch delete-then-restore) and model
  section splits/merges explicitly.
* Support unnumbered and wrapped headings with a layout model (e.g. a
  LayoutLM-style classifier) if the corpus grows beyond this manual.

## 11. Decision log

**What is most likely to silently give wrong results without erroring? How would I catch it?**
The version matcher. Staleness is only as correct as the decision "this v2 node
is the same requirement as that v1 node". If R3/R4 links the wrong node, a test
case gets compared against a different requirement. It can then come back
`current`, or with a misleading diff, and nothing errors. I added a
low-confidence flag (linked bodies sharing < 50% text) to the matching report.
In practice I would also require a human to confirm every non-R1 match before
that version's staleness results are trusted, and keep golden expected matchings
for each real manual revision.

**Where did I choose simplicity over correctness because of time, and what would break first in production?**
Generation runs synchronously inside the POST request, and the "already
pending?" check is a read followed by a write, with no lock or unique index. Two
simultaneous identical requests both pass the check, both call the LLM, and both
store an accepted generation. That defeats the reuse policy and leaves two test
sets for one requirement. With the JSON store, concurrent workers would also lose
writes. That's the first thing I'd expect to break under real use. The fix is a
job queue plus a unique partial index on the request key in Mongo.

**One input I did not handle, and what the system does with it**
A section heading that wraps onto two lines (e.g. a long title in a future
manual). The parser takes only the first line as the title. The second line
does not start with a number, so it is kept as body text of that section, with a
warning "bold line not recognised as a numbered heading" on the node and in the
version report. Content is not lost and the anomaly is visible, but the title is
truncated and the stray line is hashed as body text. A later fix to the title
would then show up as a content change.
On the LLM side, a case that is valid JSON, cites the right section with a
correct verbatim quote, but **inverts** the requirement in its expected result
("device should *not* display E3") passes every check. The validator checks
traceability and values, not meaning.

## 12. Observations about the manual itself (for QA, not parser issues)

* §6.2 says "Anthropic recommends professional recalibration". The manufacturer
  is CardioTrack. Kept verbatim.
* §3.3 bands overlap: Stage 2 is "systolic ≥ 140", Crisis is "> 180", so a reading
  of 190 satisfies both. Good material for a boundary test.
* In v2, §4.1 still says the valve vents "within 2 seconds" while §4.2 now says E3
  auto-deflates "within 1.5 seconds". The staleness check flags §4.2 test cases;
  a reviewer should also reconcile §4.1.
